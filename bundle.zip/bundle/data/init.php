<?php
    header("Access-Control-Allow-Origin: http://localhost:8080");
    header("Access-Control-Allow-Methods: *");
    header('Access-Control-Allow-Credentials:true');
    header('Access-Control-Allow-Headers:token');
    header('Content-Type: application/json;charset=UTF-8');
    header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
    $conn = mysqli_connect("172.81.236.47","willclass","willclass","willclass","3306");
    mysqli_query($conn,"SET NAMES UTF8");
?>