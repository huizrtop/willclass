<?php
  require_once('../init.php');
  require_once('../common/vendor/autoload.php');
  date_default_timezone_set("PRC");   //系统使用北京时间
  
  use \Firebase\JWT\JWT;
  
  $key = "willclass";
  $nowtime = time();
  $token = array(
      "iss" => "192.168.0.104",
      "aud" => "192.168.0.104",
      "iat" => $nowtime,
      "nbf" => $nowtime + 10,
      "exp" => $nowtime + 1800
  );
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误regist');
  }
  $formdata = json_decode($input,true);
  $uname = $formdata['duname'];
  $upwd = $formdata['dupwd'];
  $sql = "SELECT COUNT(*) FROM w_user WHERE uname = '$uname'";
  $result = mysqli_query($conn,$sql);
  if($result){
    $count = mysqli_fetch_row($result)[0];
    if($count == 0){
      $sql = "INSERT INTO w_user(uname,upwd) VALUES('$uname',md5('$upwd'))";
      $result = mysqli_query($conn,$sql);
      if($result){
        $msg = '{"code":200,"data":2}';
        $token['data'] = $formdata;
        $jwt = JWT::encode($token, $key);
        $output =['data'=>$msg,'token'=>$jwt,'uname'=>$uname];
      }else{
        $msg = '{"code":500,"data":"3"}';
        $output =['data'=>$msg];
      }
    }else{
      $msg = '{"code":300,"data":"1"}';
      $output =['data'=>$msg];
    }
  }else{
    $msg = '{"code":500,"data":"3"}';
    $output =['data'=>$msg];
  }
  echo json_encode($output);
?>