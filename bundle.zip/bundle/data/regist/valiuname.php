<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误regist');
  }
  $formdata = json_decode($input,true);
  $uname = $formdata['duname'];
  $upwd = $formdata['dupwd'];
  $sql = "SELECT COUNT(*) FROM w_user WHERE uname = '$uname'";
  $result = mysqli_query($conn,$sql);
  if($result){
    $count = mysqli_fetch_row($result)[0];
    if($count == 0){
      $msg = '{"code":200,"data":2}';
      $output =['data'=>$msg];
    }else{
      $msg = '{"code":300,"data":"1"}';
      $output =['data'=>$msg];
    }
  }else{
    $msg = '{"code":500,"data":"3"}';
    $output =['data'=>$msg];
  }
  echo json_encode($output);
?>