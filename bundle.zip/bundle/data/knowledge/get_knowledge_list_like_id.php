<?php
/*获取知识点组合及其题量*/
require_once('./../init.php');
@$input = file_get_contents("php://input");
$idlist = json_decode($input,true);
$sql = "SELECT * FROM k_count WHERE 1 ";
foreach($idlist as $id){
  $sql .= " AND kid LIKE '%$id%' ";
}
$sql .= " ORDER BY ct DESC ";
$result = mysqli_query($conn,$sql);
if($result){
  $rows = mysqli_fetch_all($result,MYSQLI_ASSOC);
  echo json_encode($rows);
}
?>