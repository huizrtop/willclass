<?php
/**
* 更新题目信息
*/
require_once('./../init.php');
@$input = file_get_contents("php://input");
$input = json_decode($input,true);
$Id = $input[0]['id'];
@$rm = $input[0]['remark'];
@$un = $input[0]['unusual'];
@$isD = $input[0]['isDemo'];
@$mk = $input[0]['marks'];
@$uname = $input[1];
 
$sql = "UPDATE exercise SET watched = 2,uname = '$uname' ";
if($rm !== "" && $rm !== null){
    $sql .= " ,remark = $rm ";
}
if($un !== "" && $un !== null){
    $sql .= " ,unusual = $un ";
}
if($isD !== "" && $isD !== null){
    $sql .= " ,isDemo = $isD ";
}
if($mk !==""&&$mk!==null){
    $sql .= " ,marks = '$mk' ";
}
$sql .= " WHERE id = '$Id'";
$result = mysqli_query($conn, $sql);
if($result){
    echo '{"code":200, "msg":"update succ"}';
}else{
    echo '{"code":500, "msg":"select err"}';
}