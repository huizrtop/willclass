<?php
/*
保存每次取题的数据
*/
require_once('./../init.php');
@$input = file_get_contents("php://input");
$input = json_decode($input,true);
$idlist = $input[0];
$token = $input[1];
$uname = $input[2];
$opt_time = time();
$result = true;
$sql = "UPDATE exercise_log SET status = 2 WHERE uname = '$uname' AND  status = 1";
mysqli_query($conn,$sql);
foreach($idlist as $id){
  $sql = "INSERT INTO exercise_log(tid,status,token,uname,opt_time) VALUES('$id',1,'$token','$uname',$opt_time)";
  $res = mysqli_query($conn,$sql);
  if(!$res){
    $result = false;
  }
}
if($result){
  echo '{"code":200,"msg":"get succ"}';
}
?>