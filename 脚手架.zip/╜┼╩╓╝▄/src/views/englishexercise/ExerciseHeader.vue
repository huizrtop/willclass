<template>
  <el-row class="exerciseheader">
    <el-col :span="6">
      <div class="sel">
         <el-radio class = "radio" v-model="watch" label="0" border size="small">所有题目</el-radio>
        <el-radio class = "radio" v-model="watch" label="1" border size="small">没有看过的题目</el-radio>
        <el-radio class = "radio" v-model="watch" label="2" border size="small">看过的题目</el-radio>
      </div>
    </el-col>
    <el-col :span="10">
      <div class="count">
        您正在根据题目的 <i>{{type}} </i> 进行题目检索，这个 <i>{{type}}</i> 下共有 <i>{{count}}</i> 个题目
      </div>
    </el-col>
    <el-col :span="8">
      <div class="getexercise">
         <el-tag class="tag" type="" effect="dark" @click="getExerciseList(count)" v-if="count !==0">取出所有题目</el-tag>
         <el-tag class="tag" type="success" effect="dark" v-if="count>= 200" @click="getExerciseList(200)">取出200个题</el-tag>
         <el-tag class="tag" type="info" effect="dark" v-if="count>= 150" @click="getExerciseList(150)">取出150个题</el-tag>
         <el-tag class="tag" type="danger" effect="dark" v-if="count>= 100" @click="getExerciseList(100)">取出100个题</el-tag>
         <el-tag class="tag" type="warning" effect="dark" v-if="count>= 50" @click="getExerciseList(50)">取出50个题</el-tag>
       </div>
    </el-col>
  </el-row>
</template>

<script>
export default {
  name: 'ExerciseHeader',
  data () {
    return {
      watch: '0',
      count: Number,
      type: String
    }
  },
  methods: {
    getCount () {
      let kn = sessionStorage.getItem('enknlist')
      let type = sessionStorage.getItem('type')
      this.$http.post('/english/get_exercise_list_kn_count.php', [kn, this.watch, type]).then(res => {
        this.count = res.data
      })
    },
    getExerciseList (n) {
      this.$message({ message: '正在检索题目', type: 'info' })
      let kn = sessionStorage.getItem('enknlist')
      let type = sessionStorage.getItem('type')
      this.$http.post('/english/get_exercise_list_kn.php', [kn, n, this.watch, type]).then(res => {
        this.$emit('getList', res.data)
        this.$message({ message: '题目检索成功', type: 'success' })
      })
    }
  },
  watch: {
    watch () {
      this.getCount()
      this.$emit('getList', [])
    }
  },
  mounted () {
    this.count = parseInt(sessionStorage.getItem('count'))
    this.type = sessionStorage.getItem('type')
  }
}
</script>

<style>
  .exerciseheader .getexercise{
    line-height: 60px;
    padding-left: 10px;
  }
  .exerciseheader .getexercise .tag{
    margin: 3px;
    cursor: pointer;
  }
  .exerciseheader .sel{
    line-height: 60px;
  }
  .exerciseheader .sel .radio{
    margin-right: 1px;
  }
  .exerciseheader .count{
    color: #3d424d;
    border-left: solid 2px #fff;
    border-right: solid 2px #fff;
    padding: 0 10px;
    height: 60px;
  }
  .exerciseheader .count i{
    color: red;
  }
</style>
