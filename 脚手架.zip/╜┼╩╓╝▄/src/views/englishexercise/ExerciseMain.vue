<template>
  <el-card class="box-card exercisemain">
    <el-dialog
  title="添加知识点"
  :visible.sync="dialogVisible"
  width="68%">
  <knowledge-tree @loadKn = "loadKn" :treei="tree"></knowledge-tree>
  <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
  </span>
</el-dialog>
    <el-table :data="tableData" border style="width: 100%" stripe>
      <el-table-column type="index" width="40"></el-table-column>
      <el-table-column prop="tid" label="题目ID"  width="150">
        <template slot-scope="scope">
          <a @click.prevent="jumpto(scope.row)" :class="{'watched':scope.row.watch === '2'}">{{scope.row.tid }}{{scope.row.watch === '2'?"☑":""}}</a>
        </template>
      </el-table-column>
      <el-table-column prop="type" label="题目类型" width="78"></el-table-column>
      <el-table-column prop="mainknowledge" label="主知识点" width="78">
        <template slot-scope="scope">
          <el-tooltip class="item" effect="dark" :content="scope.row.mainknowledge" placement="top">
            <el-button type="primary" size="mini">查看</el-button>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column prop="knowledge" label="知识点" width="78">
        <template slot-scope="scope">
          <el-tooltip class="item" effect="dark" :content="scope.row.knowledge" placement="top">
            <el-button type="primary" size="mini">查看</el-button>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column prop="duplicate" label="是否重题" width="154">
        <template slot-scope="scope">
          <el-radio class = "radio" v-model="scope.row.duplicate" @change="handleChange(scope.row)" label="1" border size="mini">是</el-radio>
          <el-radio class = "radio" v-model="scope.row.duplicate" @change="handleChange(scope.row)" label="2" border size="mini">否</el-radio>
        </template>
      </el-table-column>
      <el-table-column prop="marks" label="题目备注" show-overflow-tooltip>
        <template slot-scope="scope">
          <el-input type="textarea" :rows = '1' placeholder="请输入内容"  @change="handleChange(scope.row)" v-model="scope.row.marks"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="新知识点" width="80">
        <template slot-scope="scope">
          <el-button @click="addKn(scope.row)" type="primary" size="mini">添加</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="newknname" label="新知识点" width="120">
        <template slot-scope="scope">
          <el-tooltip class="item" effect="dark" :content="scope.row.newfuname" placement="top">
            <span>{{scope.row.newknname}}</span>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column prop="isDemo" label="是否样题" width="154">
        <template slot-scope="scope">
          <el-radio class = "radio" v-model="scope.row.isDemo" @change="handleChange(scope.row)" label="1" border size="mini">是</el-radio>
          <el-radio class = "radio" v-model="scope.row.isDemo" @change="handleChange(scope.row)" label="2" border size="mini">否</el-radio>
        </template>
      </el-table-column>
      <el-table-column prop="category" label="所属抽屉" width="200">
        <template slot-scope="scope">
          <el-input type="textarea" autosize placeholder="请输入内容" v-model="scope.row.category" @change="handleChange(scope.row)"></el-input>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="80">
        <template slot-scope="scope">
          <el-button @click="saveInfo(scope.row)" type="primary" size="small">保存</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>

<script>
import KnowledgeTree from './KnowledgeTree.vue'
export default {
  name: 'ExerciseMain',
  props: {
    elist: Array
  },
  data () {
    return {
      tableData: [],
      dialogVisible: false,
      index: 0,
      tree: 0
    }
  },
  components: { KnowledgeTree },
  watch: {
    elist: {
      handler (newVal) {
        this.tableData = newVal
      },
      deep: true
    },
    dialogVisible (newVal) {
      if (newVal) {
        this.tree++
      }
    }
  },
  mounted () {
    this.tableData = this.elist
  },
  methods: {
    handleChange (row) {
      row.watched = 2
      this.$set(row, 'watch', '2')
      this.$emit('elistChange', row)
    },
    saveInfo (row) {
      let uname = localStorage.getItem('uname')
      this.$http.post('/english/update_exercise_id.php', [row, uname]).then(res => {
        this.$message({ message: '保存成功！！', type: 'success' })
        this.handleChange(row)
      })
    },
    jumpto (row) {
      let url = 'https://emp.willclass.com/basic/newExerciseData/detail?exerciseId=' + row.tid
      // let url = row.tid.length > 8 ? 'http://emp.willclass.com/basic/newExerciseData/detail?exerciseId=' + row.tid : 'http://newopen.willclass.com/emp-exercise-detail?exerciseId=' + row.tid + '&isAlternateExercise=0&subjectId=3&isIntroduce=1'
      window.open(url, 'watch')
      this.$set(row, 'watch', '2')
    },
    addKn (row) {
      this.dialogVisible = true
      this.index = row.index
    },
    loadKn (res) {
      let item = this.tableData[this.index]
      item.newknowledge = res[0]
      this.$http.post('/english/get_fullknowledgename_id.php', res[0]).then(res => {
        item.newfuname = res.data
      })
      item.newknname = res[1]
      this.tableData = this.tableData.map(data => data.tid === item.tid ? item : data)
    },
    handleClose (done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
        })
        .catch(_ => {})
    }
  }
}
</script>

<style>
  .exercisemain .radio{
    margin: 0px;
    color: #000;
  }
  .exercisemain a{
    cursor: pointer;
    color: #000;
  }
  .exercisemain a.watched{
    color: green;
  }
</style>
