<template>
  <el-container class="exercisecontainer">
    <div class="top">
      <exercise-top></exercise-top>
    </div>
    <el-header class="header">
      <exercise-header @getList = 'getList'></exercise-header>
    </el-header>
    <div class="middle" v-if="elistLen !== 0">
      <exercise-middle :elistLen="elistLen" :elist = "elist" :showBegin = "showBegin" @showTable="showTable" @selDataChange ="selDataChange"></exercise-middle>
    </div>
    <el-main class="main"  v-if="elistLen !== 0">
      <exercise-main :elist = "result" @elistChange = "resultChange" v-show="showTale"></exercise-main>
    </el-main>
  </el-container>
</template>

<script>
import ExerciseTop from './ExerciseTop.vue'
import ExerciseHeader from './ExerciseHeader.vue'
import ExerciseMiddle from './ExerciseMiddle.vue'
import ExerciseMain from './ExerciseMain.vue'
export default {
  name: 'Exercise',
  components: { ExerciseTop, ExerciseHeader, ExerciseMiddle, ExerciseMain },
  data () {
    return {
      elist: [],
      elistLen: 0,
      showTale: false,
      selData: Object,
      showBegin: 0,
      result: []
    }
  },
  methods: {
    filter (data) {
      let result = true
      if (parseInt(this.selData.watch) !== 0) {
        result = parseInt(this.selData.watch) === parseInt(data.watch)
      }
      if (result && parseInt(this.selData.isDup) !== 0) {
        result = parseInt(this.selData.isDup) === parseInt(data.duplicate)
      }
      if (result && this.selData.isDemo) {
        result = parseInt(data.isDemo) === 1
      }
      if (result && this.selData.newkn !== '') {
        let word = '.*' + this.selData.newkn + '.*'
        let reg = new RegExp(word)
        result = reg.test(data.newknname)
      }
      if (result && this.selData.mark !== '') {
        let word = '.*' + this.selData.mark + '.*'
        let reg = new RegExp(word)
        result = reg.test(data.marks)
      }
      if (result && this.selData.category !== '') {
        let word = '.*' + this.selData.category + '.*'
        let reg = new RegExp(word)
        result = reg.test(data.category)
      }
      return result
    },
    getList (list) {
      this.elist = list
      this.elistLen = list.length
      this.result = list
      this.showBegin++
      this.showTale = false
    },
    showTable (showTable) {
      this.showTale = showTable
    },
    selDataChange (selData) {
      this.selData = selData
      this.result = this.elist.filter(data => this.filter(data))
    },
    resultChange (row) {
      this.elist = this.elist.map(data => data.id === row.id ? row : data)
    }
  },
  watch: {
    elistLen () {
      if (this.elistLen === 0) {
        this.showTale = false
      }
    }
  }
}
</script>

<style>
.exercisecontainer {
  height: 100%;
}
.exercisecontainer .top {
  background-color: #3d424d;
  min-height: 50px;
  display: fixed;
}
.exercisecontainer .header{
  background-color: #b3c0d1;
  height: 60px;
}
.exercisecontainer .middle{
  background: #E4EBFF;
  height: 120px;
}
.exercisecontainer .main {
  background-color: #e9eef3;
  height: 100%;
}
</style>
