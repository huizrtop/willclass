<template>
  <el-card class="box-card">
  <div slot="header" class="clearfix">
    <span>数学知识点图谱</span>
  </div>
  <div class="text item">
    <el-table :data="tableData" :span-method="objectSpanMethod" border style="width: 100%; margin-top: 20px">
    <el-table-column type="index" width="50"></el-table-column>
      <el-table-column prop="kn1" label="一级知识点"></el-table-column>
      <el-table-column prop="kn2" label="二级知识点"></el-table-column>
      <el-table-column prop="kn3" label="三级知识点"></el-table-column>
    </el-table>
  </div>
</el-card>
</template>

<script>
export default {
  name: 'MathKnowledge',
  data () {
    return {
      tableData: [],
      kn1space: [],
      kn2space: [],
      tiaojian: ''
    }
  },
  computed: {
    kn1index () {
      let indexarr = []
      for (let i = 0; i < this.kn1space.length; i++) {
        let index = 0
        for (let j = 0; j < i; j++) {
          index += this.kn1space[j]
        }
        indexarr.push(index)
      }
      return indexarr
    },
    kn2index () {
      let indexarr = []
      for (let i = 0; i < this.kn2space.length; i++) {
        let index = 0
        for (let j = 0; j < i; j++) {
          index += this.kn2space[j]
        }
        indexarr.push(index)
      }
      return indexarr
    }
  },
  methods: {
    objectSpanMethod ({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 1) {
        return this.runSpan(rowIndex, this.kn1index, this.kn1space)
      } else if (columnIndex === 2) {
        return this.runSpan(rowIndex, this.kn2index, this.kn2space)
      }
    },
    runSpan (rowIndex, kn11, kn12) {
      let index = kn11.indexOf(rowIndex)
      if (index !== -1) {
        return {
          rowspan: kn12[index],
          colspan: 1
        }
      } else {
        return {
          rowspan: 0,
          colspan: 0
        }
      }
    }
  },
  mounted () {
    this.$http.post('/english/get_english_knowledge.php', 1).then(res => {
      this.tableData = res.data.kntable
      this.kn1space = res.data.kn1space
      this.kn2space = res.data.kn2space
    })
  }
}
</script>

<style>

</style>
