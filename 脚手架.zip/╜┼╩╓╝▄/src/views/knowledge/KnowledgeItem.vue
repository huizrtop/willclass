<template>
  <tr class="knowledgeitem">
    <td>
      <span v-for="(ite,index) in item.idname" :key = index>{{ite.slice(0,-12)}}</span>
    </td>
    <td>{{item.ct}}</td>
    <td>未看</td>
    <td><span @click="jumpto">看题</span></td>
  </tr>
</template>

<script>
export default {
  name: 'KnowledgeItem',
  props: {
    item: Object
  },
  methods: {
    jumpto () {
      localStorage.klist = this.item.idname
      this.$router.push({ 'name': 'exercise' })
    }
  }
}
</script>

<style>
 .knowledgeitem td span{
    display: inline-block;
    padding: 3px 8px;
    background: #108EE9;
    color: #FFF;
    border-radius: 5px;
    margin: 5px;
    cursor: pointer;
  }
</style>
