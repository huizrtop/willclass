<template>
  <tr class="tablehead">
    <th>知识点名称</th>
    <th>题目数量</th>
    <th>状态</th>
    <th>操作</th>
  </tr>
</template>

<script>
export default {
  name: 'TableHead'
}
</script>

<style>
  .tablehead{
    height: 40px;
    background: #F7F7F7;
    font-size: 16px;
  }
  .knowledgebox .tablehead th:first-child{
    width: 800px;
  }
.tablehead th:nth-child(3){
  width: 80px;
}
.tablehead th:nth-child(4){
  width: 80px;
}
</style>
