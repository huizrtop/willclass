<template>
  <div class="knowledge">
    <top-box @elist = 'getlist'></top-box>
    <hr>
    <knowledge-box  v-if="klist.length !== 0" :klist = "klist"></knowledge-box>
  </div>
</template>

<script>
import TopBox from './TopBox.vue'
import KnowledgeBox from './KnowledgeBox.vue'
export default {
  name: 'Knowledge',
  components: {
    TopBox,
    KnowledgeBox
  },
  data () {
    return {
      klist: []
    }
  },
  methods: {
    getlist (val) {
      this.klist = val
    }
  }
}
</script>

<style>

</style>
