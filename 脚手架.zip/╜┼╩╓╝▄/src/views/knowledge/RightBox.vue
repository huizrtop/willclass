<template>
  <div class="right-box">
    <div class="txt" v-if="count.length != 0">
      包含该知识点组合的知识点组合共有：<span>{{count.length}}</span>个；
      其中，所含题目超过<i> 200 </i>个的有：<span>{{a.length}}</span>个；
      题量超过<i> 150 </i>个的有：<span>{{b.length}}</span>个；
      题量超过<i> 100 </i>个的有：<span>{{c.length}}</span>个；
      题量超过<i> 50 </i>个的有：<span>{{d.length}}</span>个；
      题量超过<i> 10 </i>个的有：<span>{{e.length}}</span>个；
      题量超过<i> 5 </i>个的有：<span>{{f.length}}</span>个；
      题量不足<i> 5 </i>个的有：<span>{{g.length}}</span>个；
    </div>
    <div class="txt" v-else><span>没有包含该知识点组合知识点组合，请尝试其他知识点组合！！！！</span></div>
    <hr>
    <div class="searbtn" v-if="count.length != 0">
      <span @click="searchList(count)">取出所有题目</span>
      <span v-if="a.length != 0" @click="searchList(a)">取出题量超过 200 的组合</span>
      <span v-if="b.length != 0" @click="searchList(b)">取出题量超过 150 的组合</span>
      <span v-if="c.length != 0" @click="searchList(c)">取出题量超过 100 的组合</span>
      <span v-if="d.length != 0"  @click="searchList(d)">取出题量超过 50 的组合</span>
      <span v-if="e.length != 0"  @click="searchList(e)">取出题量超过 10 的组合</span>
      <span v-if="f.length != 0"  @click="searchList(f)">取出题量超过 5 的组合</span>
      <span v-if="g.length != 0"  @click="searchList(g)">取出题量不足 5 的组合</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'RightBox',
  props: {
    count: Array
  },
  computed: {
    a () {
      return this.count.filter(item => item.ct >= 200)
    },
    b () {
      return this.count.filter(item => item.ct >= 150)
    },
    c () {
      return this.count.filter(item => item.ct >= 100)
    },
    d () {
      return this.count.filter(item => item.ct >= 50)
    },
    e () {
      return this.count.filter(item => item.ct >= 10)
    },
    f () {
      return this.count.filter(item => item.ct >= 5)
    },
    g () {
      return this.count.filter(item => item.ct < 5)
    }
  },
  methods: {
    searchList (list) {
      this.$http.post('knowledge/get_knowledge_name.php', list).then(res => {
        this.$emit('elist', res.data)
        this.$message({
          message: '成功取出知识点组合！！！',
          type: 'success'
        })
      })
    }
  }
}
</script>

<style>
  .right-box{
    margin-left: 10px;
    width: 70%;
  }
  .right-box>.txt,.right-box>.txt>span,.right-box>.searbtn{
    padding: 5px;
  }
  .right-box>.txt>span{
    color: red;
  }
  .right-box>.txt>i{
    color: green;
    font-weight: bold;
  }
  .right-box>.searbtn>span{
    display: inline-block;
    padding: 3px 8px;
    background: #108EE9;
    color: #FFF;
    border-radius: 5px;
    margin: 5px;
    cursor: pointer;
  }
</style>
