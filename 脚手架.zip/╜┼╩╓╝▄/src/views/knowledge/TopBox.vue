<template>
  <div class="topbox">
    <left-box @countShow = "countShow" @emptydata = "emptydata"></left-box>
    <right-box v-if="count.length !==0 && isEmpty" :count = "count" @elist = "elist"></right-box>
  </div>
</template>

<script>

import LeftBox from './LeftBox.vue'
import RightBox from './RightBox.vue'

export default {
  name: 'TopBox',
  components: {
    LeftBox,
    RightBox
  },
  data () {
    return {
      count: [],
      isEmpty: false
    }
  },
  methods: {
    countShow (val) {
      this.count = val
      this.isEmpty = true
    },
    emptydata () {
      this.isEmpty = false
    },
    elist (val) {
      this.$emit('elist', val)
    }
  },
  watch: {
    isEmpty () {
      if (!this.isEmpty) {
        this.$emit('clearTable')
      }
    }
  }
}
</script>

<style scoped>
  .topbox{
    margin-bottom:  10px;
    display: flex;
  }
</style>
