<template>
    <table class="knowledgebox">
      <thead><table-head></table-head></thead>
      <tbody>
        <knowledge-item v-for="item in klist" :key = item.id :item = "item"></knowledge-item>
      </tbody>
    </table>
</template>

<script>
import TableHead from './TableHead.vue'
import KnowledgeItem from './KnowledgeItem.vue'
export default {
  name: 'KnowledgeBox',
  props: {
    klist: Array
  },
  components: {
    TableHead,
    KnowledgeItem
  }
}
</script>

<style>
  .knowledgebox, .knowledgebox th, .knowledgebox td{
    border: 1px solid #808080;
    border-collapse:collapse;
    padding: 2px 8px;
    text-align: center;
  }
  .knowledgebox{
    margin: 0 auto;
  }
</style>
