<template>
  <el-card class="box-card exercisemain">
    <el-dialog
  title="添加题材"
  :visible.sync="dialogVisible"
  width="68%">
  <theme-tree @loadKn = "loadKn" :treei = "tree"></theme-tree>
  <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
  </span>
</el-dialog>
    <el-table :data="tableData" border style="width: 100%" stripe>
      <el-table-column type="index" width="40"></el-table-column>
      <el-table-column prop="tid" label="题目ID"  width="150">
        <template slot-scope="scope">
          <a @click.prevent="jumpto(scope.row)" :class="{'watched':scope.row.watch === '2'}">{{scope.row.tid }}{{scope.row.watch === '2'?"☑":""}}</a>
        </template>
      </el-table-column>
      <el-table-column prop="type" label="题目类型" width="78"></el-table-column>
      <el-table-column prop="quality" label="题目质量" width="78"></el-table-column>
      <el-table-column prop="duplicate" label="是否重题" width="154">
        <template slot-scope="scope">
          <el-radio class = "radio" v-model="scope.row.duplicate" @change="handleChange(scope.row)" label="1" border size="mini">是</el-radio>
          <el-radio class = "radio" v-model="scope.row.duplicate" @change="handleChange(scope.row)" label="2" border size="mini">否</el-radio>
        </template>
      </el-table-column>
      <el-table-column prop="isDrop" label="是否废弃" width="154">
        <template slot-scope="scope">
          <el-radio class = "radio" v-model="scope.row.isDrop" @change="handleChange(scope.row)" label="1" border size="mini">是</el-radio>
          <el-radio class = "radio" v-model="scope.row.isDrop" @change="handleChange(scope.row)" label="2" border size="mini">否</el-radio>
        </template>
      </el-table-column>
      <el-table-column prop="marks" label="题目备注" show-overflow-tooltip>
        <template slot-scope="scope">
          <el-input type="textarea" :rows = '1' placeholder="请输入内容"  @change="handleChange(scope.row)" v-model="scope.row.marks"></el-input>
        </template>
      </el-table-column>
      <el-table-column prop="isHot" label="是否热点" width="154">
        <template slot-scope="scope">
          <el-radio class = "radio" v-model="scope.row.isHot" @change="handleChange(scope.row)" label="1" border size="mini">是</el-radio>
          <el-radio class = "radio" v-model="scope.row.isHot" @change="handleChange(scope.row)" label="2" border size="mini">否</el-radio>
        </template>
      </el-table-column>
      <el-table-column label="体裁" width = '150'>
        <template slot-scope="scope">
          <el-autocomplete class="inline-input" v-model="scope.row.lname" size="mini" :fetch-suggestions="querySearch" placeholder="请输入内容"  @select="handleSelect(scope.row)"
    ></el-autocomplete>
        </template>
      </el-table-column>
      <el-table-column label="题材" width="80">
        <template slot-scope="scope">
          <el-button @click="addKn(scope.row)" type="primary" size="mini">添加</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="themeName" label="题材" width="120">
        <template slot-scope="scope">
          <el-tooltip class="item" effect="dark" :content="scope.row.lfuname" placement="top">
            <span>{{scope.row.themeName}}</span>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="80">
        <template slot-scope="scope">
          <el-button @click="saveInfo(scope.row)" type="primary" size="small">保存</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>

<script>
import ThemeTree from './ThemeTree.vue'
export default {
  name: 'ExerciseMain',
  props: {
    elist: Array
  },
  data () {
    return {
      tableData: [],
      dialogVisible: false,
      tree: 0,
      index: 0,
      lname: [
        { 'value': '记叙文', 'id': 1 },
        { 'value': '议论文', 'id': 2 },
        { 'value': '说明文', 'id': 3 },
        { 'value': '夹叙夹议文', 'id': 4 },
        { 'value': '应用文', 'id': 5 }
      ]
    }
  },
  components: { ThemeTree },
  watch: {
    elist: {
      handler (newVal) {
        this.tableData = newVal
      },
      deep: true
    },
    dialogVisible (val) {
      if (val) {
        this.tree++
      }
    }
  },
  mounted () {
    this.tableData = this.elist
  },
  methods: {
    handleChange (row) {
      row.watch = 2
      this.$set(row, 'watch', '2')
      this.$emit('elistChange', row)
    },
    saveInfo (row) {
      let uname = localStorage.getItem('uname')
      this.$http.post('/english/reading/update_exercise_id.php', [row, uname]).then(res => {
        if (parseInt(res.data.code) === 200) {
          this.$message({ message: '保存成功！！', type: 'success' })
          this.handleChange(row)
        }
      })
    },
    jumpto (row) {
      let url = row.tid.length > 8 ? 'http://emp.willclass.com/basic/newExerciseData/detail?exerciseId=' + row.tid : 'http://newopen.willclass.com/emp-exercise-detail?exerciseId=' + row.tid + '&isAlternateExercise=0&subjectId=3&isIntroduce=1'
      window.open(url, 'watch')
      this.$set(row, 'watch', '2')
    },
    addKn (row) {
      this.dialogVisible = true
      this.index = row.index
    },
    loadKn (res) {
      let item = this.tableData[this.index - 1]
      this.$http.post('/english/reading/get_fullthemename_id.php', res[0]).then(res => {
        item.themeId = res.data.themeId
        item.lfuname = res.data.lfuname
        item.themeName = res.data.themeName
      })
      this.tableData = this.tableData.map(data => data.tid === item.tid ? item : data)
    },
    handleClose (done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done()
        })
        .catch(_ => {})
    },
    querySearch (queryString, cb) {
      let lname = this.lname
      let results = queryString ? lname.filter(this.createFilter(queryString)) : lname
      cb(results)
    },
    createFilter (queryString) {
      return (restaurant) => {
        return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handleSelect (item) {
      item.literature = item.lname === '记叙文' ? 1 : item.lname === '议论文' ? 2 : item.lname === '说明文' ? 3 : item.lname === '夹叙夹议文' ? 4 : item.lname === '应用文' ? 5 : 0
      this.tableData = this.tableData.map(data => data.id === item.id ? item : data)
    }
  }
}
</script>

<style>
  .exercisemain .radio{
    margin: 0px;
    color: #000;
  }
  .exercisemain a{
    cursor: pointer;
    color: #000;
  }
  .exercisemain a.watched{
    color: green;
  }
</style>
