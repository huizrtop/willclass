<template>
<div>
  <div>
    已经选择的题材：
    <el-tag
    v-for="item in getKn"
    :key="item.id"
    type="primary"
    class = "kntreeget"
    effect="dark">
    {{ item.label }}
  </el-tag>
  </div>
  <el-input
  placeholder="输入关键字进行过滤"
  v-model="filterText">
</el-input>
<el-tree
  class="filter-tree"
  :data="data"
  show-checkbox
  node-key="id"
  ref="tree"
  @check-change = "getCheckedNodes"
  highlight-current
  :filter-node-method="filterNode"
  :props="defaultProps">
</el-tree>
</div>
</template>

<script>
export default {
  name: 'KnowledgeTree',
  props: {
    treei: Number
  },
  data () {
    return {
      data: [],
      getKn: [],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      filterText: ''
    }
  },
  watch: {
    filterText (val) {
      this.$refs.tree.filter(val)
    },
    treei () {
      this.resetChecked()
    }
  },
  methods: {
    filterNode (value, data) {
      if (!value) return true
      return data.label.indexOf(value) !== -1
    },
    getCheckedNodes () {
      this.getKn = this.$refs.tree.getCheckedNodes()
      this.getKn.map(data => data.label)
      this.$emit('loadKn', [this.getKn.map(data => data.id).join('#'), this.getKn.map(data => data.label).join('#')])
    },
    resetChecked () {
      this.$refs.tree.setCheckedKeys([])
    }
  },
  mounted () {
    this.$http.get('/english/reading/get_english_theme_list.php').then(res => {
      this.data = res.data
    })
  }
}
</script>

<style>
  .kntreeget{
    margin: 5px;
  }
</style>
