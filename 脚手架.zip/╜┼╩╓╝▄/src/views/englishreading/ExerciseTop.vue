<template>
  <el-row class="exercisetop">
      <el-col :span="2"><div class="myhome">题目类型为：</div></el-col>
      <el-col :span="20">
        <div class="knowledge">
          <el-tag class="tag" type ="primary"  effect="dark">
            {{ ttype }}
          </el-tag>
        </div>
      </el-col>
      <el-col :span="2">
        <div class="myhome">
          <h4 @click="gohome">个人中心</h4>
        </div>
      </el-col>
    </el-row>
</template>

<script>
export default {
  name: 'ExerciseTop',
  data () {
    return {
      ttype: ''
    }
  },
  methods: {
    gohome () {
      this.$router.push({ name: 'mytask' })
    }
  },
  mounted () {
    this.ttype = sessionStorage.getItem('ttype')
  }
}
</script>

<style>
  .exercisetop .myhome{
    line-height: 60px;
    text-align: center;
    color: #FFFFFF;
  }
  .exercisetop .myhome h4{
    cursor: pointer;
  }
  .exercisetop .knowledge{
    padding: 3px;
    border-left: 1px solid #fff;
    border-right: 1px solid #fff;
    min-height: 60px;
  }
  .exercisetop .knowledge .tag{
    margin: 1px;
  }
</style>
