<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>我的任务进度</span>
      <el-button style="float: right; padding: 3px 0" type="text" @click="jumpCurrent">查看当前任务</el-button>
    </div>
    <div class="text item">
      我需完成的知识点数：{{count.total}}个，已完成：{{count.deal}}个，未完成：{{count.undeal}}个，有 {{count.dealing}} 个正在处理
      <hr>
    </div>
    <div class="text item">
      <el-table :data="tableData" :span-method="objectSpanMethod" border style="width: 100%; margin-top: 20px">
        <el-table-column prop="username" label="处理人" width="100"></el-table-column>
        <el-table-column prop="knowledgeId" label="知识点ID" width="120"></el-table-column>
        <el-table-column prop="knowledgeName" label="知识点名称" show-overflow-tooltip
          ></el-table-column>
        <el-table-column prop="tcount" label="题目数量" width="80"></el-table-column>
        <el-table-column prop="categoryCount" label="抽屉数量" width="80"></el-table-column>
        <el-table-column prop="status" label="当前状态" width="100">
          <template slot-scope="scope">{{ scope.row.status === '1'?'未处理': scope.row.status === '2'?'处理中':'已完成'}}</template>
        </el-table-column>
        <el-table-column fixed="right" label="操作" width="100">
          <template slot-scope="scope">
            <el-button @click="handleClick(scope.row)" type="primary" size="small" v-if="scope.row.status === '1'">开始处理</el-button>
            <el-button @click="handleClick(scope.row)" type="success" size="small" v-if="scope.row.status === '2'">开始处理</el-button>
            <el-button @click="handleClick(scope.row)" type="info" size="small" v-if="scope.row.status === '3'">重新处理</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
   </el-card>
</template>

<script>
export default {
  name: 'MySchedule',
  data () {
    return {
      count: Object,
      tableData: [ ]
    }
  },
  methods: {
    objectSpanMethod ({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0) {
          return {
            rowspan: this.tableData.length,
            colspan: 1
          }
        } else {
          return {
            rowspan: 0,
            colspan: 0
          }
        }
      }
    },
    handleClick (row) {
      if (row.status === '2') {
        sessionStorage.kidlist = row.knowledgeId
        sessionStorage.knlist = row.knowledgeName
        this.$router.push({ 'name': 'exercise' })
      } else if (row.status === '1' || row.status === '3') {
        if (this.count.dealing === '1') {
          this.$message({ message: '您还有正在处理的知识点哦～', type: 'warning' })
        } else {
          let uname = localStorage.getItem('uname')
          this.$http.post('/exercise/clearStorage.php', uname)
          this.$http.post('/taskmanager/beginTask.php', row.knowledgeId).then(res => {
            if (res.data.code === '200') {
              this.$message({ message: '操作成功～', type: 'success' })
              sessionStorage.knlist = row.knowledgeName
              sessionStorage.kidlist = row.knowledgeId
              this.$router.push({ 'name': 'exercise' })
            }
          })
        }
      }
    },
    jumpCurrent () {
      this.$router.push({ name: 'mytask' })
    }
  },
  mounted () {
    let uname = localStorage.getItem('uname')
    this.$http.post('/taskmanager/mySchedule.php', uname).then(res => {
      this.count = res.data.count
      this.tableData = res.data.tableData
    })
  }
}
</script>

<style>

</style>
