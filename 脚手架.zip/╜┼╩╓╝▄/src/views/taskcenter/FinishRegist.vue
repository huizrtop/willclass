<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>我的任务进度</span>
      <el-button style="float: right; padding: 3px 0" type="text" @click="handleClickTo">查看总任务进度</el-button>
    </div>
    <div class="text item">
      <el-table
        :data="tableData"
        border
        style="width: 100%; margin-top: 20px">
        <el-table-column
          prop="username"
          label="处理人"
          width="100">
        </el-table-column>
        <el-table-column
          prop="knowledgeId"
          label="知识点ID"
          width="120">
        </el-table-column>
        <el-table-column
          prop="knowledgeName"
          label="知识点名称"
          show-overflow-tooltip
          >
        </el-table-column>
        <el-table-column
          prop="tcount"
          label="题目数量"
          width="80">
        </el-table-column>
        <el-table-column
          prop="categoryCount"
          label="抽屉数量"
          width="80">
        </el-table-column>
        <el-table-column
          prop="status"
          label="当前状态"
          width="100">
          <template slot-scope="scope">{{ scope.row.status === '1'?'未处理': scope.row.status === '2'?'处理中':'已完成'}}</template>
        </el-table-column>
        <el-table-column
          fixed="right"
          label="操作"
          width="100">
          <template slot-scope="scope">
            <el-button @click="dialogFormVisible = true" type="success" size="small" v-if="scope.row.status === '2'" >登记完成</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog title="知识点抽屉建立完成登记表" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item label="该知识点（组合）产生的抽屉数为：">
          <el-input v-model="form.categoryCount" autofocus="true" type = "number"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleClick">确 定</el-button>
      </div>
    </el-dialog>
   </el-card>
</template>

<script>
export default {
  name: 'FinishRegist',
  data () {
    return {
      tableData: [],
      dialogFormVisible: false,
      form: {
        categoryCount: ''
      }
    }
  },
  mounted () {
    let uname = localStorage.getItem('uname')
    this.$http.post('/taskmanager/finishRegistStatus.php', uname).then(res => {
      this.tableData = res.data
    })
  },
  methods: {
    handleClick () {
      this.dialogFormVisible = false
      this.$http.post('/taskmanager/finishRegist.php', [this.form.categoryCount, this.tableData[0].knowledgeId]).then(res => {
        if (res.data.code === '200') {
          this.$message({ message: '登记成功！！', type: 'success' })
          this.$router.push({ name: 'myschedule' })
        }
      })
    },
    handleClickTo () {
      this.$router.push({ name: 'myschedule' })
    }
  }
}
</script>

<style>

</style>
