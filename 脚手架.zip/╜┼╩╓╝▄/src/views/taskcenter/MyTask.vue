<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>我的任务中心</span>
      <el-button style="float: right; padding: 3px 0" type="text" @click="handleClick1">查看总进度</el-button>
    </div>
    <div class="text item">
      我当前正在处理的知识点是：{{kinfo.kn}}
      <el-button style="float: right; padding: 3px 0" type="text" @click="handleClick2">继续看题</el-button>
      <hr>
    </div>
    <div class="text item">
      这个知识点一共 {{kinfo.ct}} 题，已看 {{kinfo.watched}} 题，未看 {{kinfo.watch}} 题
      <hr>
    </div>
    <div class="text item">
      我需要完成的知识点数：{{count.total}} 个，已完成：{{count.deal}} 个，未完成 {{count.undeal}} 个
      <el-button style="float: right; padding: 3px 0" type="text" @click="handleClick1">查看详情</el-button>
    </div>
   </el-card>
</template>

<script>
export default {
  name: 'MyTask',
  data () {
    return {
      kinfo: Object,
      count: Object
    }
  },
  mounted () {
    let uname = localStorage.getItem('uname')
    this.$http.post('/taskmanager/mytask.php', uname).then(res => {
      this.kinfo = res.data.kinfo
      this.count = res.data.count
    })
  },
  methods: {
    handleClick1 () {
      this.$router.push({ name: 'myschedule' })
    },
    handleClick2 () {
      sessionStorage.kidlist = this.kinfo.kid
      sessionStorage.knlist = this.kinfo.kn
      this.$router.push({ 'name': 'exercise' })
    }
  }
}
</script>

<style>

</style>
