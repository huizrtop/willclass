<template>
  <el-row class="exercisetop">
      <el-col :span="2"><div class="myhome">知识点为：</div></el-col>
      <el-col :span="20">
        <div class="knowledge">
          <el-tag class="tag"
            v-for="item in items"
            :key="item.label"
            :type="item.type"
            effect="dark">
            {{ item.label }}
          </el-tag>
        </div>
      </el-col>
      <el-col :span="2">
        <div class="myhome">
          <h4 @click="gohome">个人中心</h4>
        </div>
      </el-col>
    </el-row>
</template>

<script>
export default {
  name: 'ExerciseTop',
  data () {
    return {
      items: []
    }
  },
  methods: {
    gohome () {
      this.$router.push({ name: 'mytask' })
    }
  },
  mounted () {
    let knlist = sessionStorage.getItem('knlist')
    let knarr = knlist.split('#')
    let klist = []
    for (let i = 1; i <= knarr.length; i++) {
      let kn = knarr[ i - 1 ]
      if (i % 5 === 1) {
        klist.push({ type: '', label: kn })
      } else if (i % 5 === 2) {
        klist.push({ type: 'success', label: kn })
      } else if (i % 5 === 3) {
        klist.push({ type: 'info', label: kn })
      } else if (i % 5 === 4) {
        klist.push({ type: 'danger', label: kn })
      } else {
        klist.push({ type: 'warning', label: kn })
      }
    }
    this.items = klist
  }
}
</script>

<style>
  .exercisetop .myhome{
    line-height: 60px;
    text-align: center;
    color: #FFFFFF;
  }
  .exercisetop .myhome h4{
    cursor: pointer;
  }
  .exercisetop .knowledge{
    padding: 3px;
    border-left: 1px solid #fff;
    border-right: 1px solid #fff;
    min-height: 60px;
  }
  .exercisetop .knowledge .tag{
    margin: 1px;
  }
</style>
