<template>
  <div class="exercisemiddle">
    <el-row>
      <el-col :span = '3'>
        <div class="selinfo">筛选表格中的题目：</div>
      </el-col>
      <el-col :span = '15'>
        <div class="selcontainer">
          <el-radio class = "radio" v-model="selData.watch" label="0" border size="small">所有题目</el-radio>
          <el-radio class = "radio" v-model="selData.watch" label="1" border size="small">没有看过的题目</el-radio>
          <el-radio class = "radio" v-model="selData.watch" label="2" border size="small">看过的题目</el-radio>
          <el-radio class = "radio" v-model="selData.isDup" label="2" border size="small">不看重题</el-radio>
          <el-radio class = "radio" v-model="selData.isDup" label="0" border size="small">包含重题</el-radio>
          <el-radio class = "radio" v-model="selData.isUn" label="2" border size="small">不看异常题</el-radio>
          <el-radio class = "radio" v-model="selData.isUn" label="0" border size="small">包含异常题</el-radio>
          <el-checkbox class="demoCheck" v-model="selData.isDemo" label="样题" border size="small"></el-checkbox>
        </div>
      </el-col>
      <el-col :span = '3'>
        <div class="info">
          已经取出 {{elistLen}} 个题目
        </div>
      </el-col>
      <el-col :span = '3'>
        <div class="oprate">
          <el-button type="primary" size="small" v-if = '!isShow' @click="beginW">开始看题</el-button>
          <el-button type="info" size="small" v-if = 'isShow'>看题中</el-button>
          <el-button type="success" size="small" v-if = 'isShow' @click="saveAll">一键保存</el-button>
        </div>
      </el-col>
    </el-row>
    <el-row class="selcontainer">
      <el-col :span = "6">
        <el-radio class = "radio" v-model="selData.type" label="1" border size="small">单选</el-radio>
        <el-radio class = "radio" v-model="selData.type" label="2" border size="small">填空</el-radio>
        <el-radio class = "radio" v-model="selData.type" label="3" border size="small">解答</el-radio>
        <el-radio class = "radio" v-model="selData.type" label="0" border size="small">所有</el-radio>
      </el-col>
      <el-col :span = "2">
        <span class="seltitle">根据备注筛选：</span>
      </el-col>
      <el-col :span = "6">
         <el-input size="small" placeholder="请输入备注内容" v-model="selData.mark"></el-input>
      </el-col>
      <el-col :span = "2">
        <span class="seltitle">根据抽屉筛选：</span>
      </el-col>
      <el-col :span = "6">
         <el-input size="small" placeholder="请输入抽屉内容" v-model="selData.category"></el-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  name: 'ExerciseMiddle',
  props: {
    elistLen: Number,
    elist: Array,
    showBegin: Number,
    saveList: Array
  },
  data () {
    return {
      isShow: false,
      selData: {
        watch: '0',
        isDup: '0',
        isUn: '0',
        type: '0',
        mark: '',
        category: '',
        isDemo: false
      }
    }
  },
  watch: {
    selData: {
      handler (newVal) {
        this.$emit('selDataChange', newVal)
      },
      deep: true
    },
    showBegin () {
      this.isShow = false
    }
  },
  methods: {
    beginW () {
      this.$message({ message: '题目加载可能延迟～', type: 'info' })
      let idlist = this.elist.map(item => item.tid)
      let token = localStorage.getItem('token')
      let uname = localStorage.getItem('uname')
      this.$http.post('/exercise/storage.php', [idlist, token, uname]).then(res => {
        this.isShow = true
        this.$emit('showTable', this.isShow)
        this.$message({ message: '题目加载成功', type: 'success' })
      })
    },
    saveAll () {
      this.$message({ message: '正在保存题目！！请稍后～', type: 'danger' })
      let uname = localStorage.getItem('uname')
      this.$http.post('/exercise/update_exercise_id_all.php', [this.saveList, uname]).then(res => {
        this.$message({ message: '保存成功！！！', type: 'success' })
      })
    }
  }
}
</script>

<style>
  .exercisemiddle .oprate,.exercisemiddle .selinfo,.exercisemiddle .info{
    padding: 0 10px;
    line-height: 60px;
  }
  .exercisemiddle .selinfo,.exercisemiddle .selcontainer{
    background: #EDF5FD;
    line-height: 60px;
    padding: 0 10px;
  }
  .exercisemiddle .selcontainer .radio{
    margin: 2px;
  }
  .exercisemiddle .selcontainer .demoCheck{
    margin: 10px;
  }
  .exercisemiddle .selcontainer .seltitle{
    color: #888;
    padding-left: 10px;
  }
  .exercisemiddle .info{
    color: red;
    border-left: 2px solid #b3c0d1;
    border-right: 2px solid #b3c0d1;
  }
</style>
