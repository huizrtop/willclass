<template>
  <el-card class="box-card exercisemain">
    <el-table :data="tableData" border style="width: 100%" stripe ref="multipleTable" tooltip-effect="dark" @selection-change="handleSelectionChange">
       <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column type="index" width="40"></el-table-column>
      <el-table-column prop="tid" label="题目ID"  width="150">
        <template slot-scope="scope">
          <a @click.prevent="jumpto(scope.row)" :class="{'watched':scope.row.watched === '2'}">{{scope.row.tid }}{{scope.row.watched === '2'?"☑":""}}</a>
        </template>
      </el-table-column>
      <el-table-column prop="type" label="题目类型" width="262">
        <template slot-scope="scope">
          <el-radio class = "radio" v-model="scope.row.type" @change="handleChange(scope.row)" label="1" border size="mini">单选</el-radio>
          <el-radio class = "radio" v-model="scope.row.type" @change="handleChange(scope.row)" label="2" border size="mini">填空</el-radio>
          <el-radio class = "radio" v-model="scope.row.type" @change="handleChange(scope.row)" label="3" border size="mini">解答</el-radio>
        </template>
      </el-table-column>
      <el-table-column prop="quality" label="题目质量"  width="80"></el-table-column>
      <el-table-column prop="remark" label="是否重题" width="154">
        <template slot-scope="scope">
          <el-radio class = "radio" v-model="scope.row.remark" @change="handleChange(scope.row)" label="1" border size="mini">是</el-radio>
          <el-radio class = "radio" v-model="scope.row.remark" @change="handleChange(scope.row)" label="2" border size="mini">否</el-radio>
        </template>
      </el-table-column>
      <el-table-column prop="unusual" label="是否异常" width="154">
        <template slot-scope="scope">
          <el-radio class = "radio" v-model="scope.row.unusual"  @change="handleChange(scope.row)" label="1" border size="mini">是</el-radio>
          <el-radio class = "radio" v-model="scope.row.unusual"  @change="handleChange(scope.row)" label="2" border size="mini">否</el-radio>
        </template>
      </el-table-column>
      <el-table-column prop="marks" label="题目备注" show-overflow-tooltip>
        <template slot-scope="scope">
          <el-input type="textarea" :rows = '1' placeholder="请输入内容"  @change="handleChange(scope.row)" v-model="scope.row.marks"></el-input>
        </template>
      </el-table-column>
      <el-table-column prop="isDemo" label="是否样题" width="154">
        <template slot-scope="scope">
          <el-radio class = "radio" v-model="scope.row.isDemo" @change="handleChange(scope.row)" label="1" border size="mini">是</el-radio>
          <el-radio class = "radio" v-model="scope.row.isDemo" @change="handleChange(scope.row)" label="2" border size="mini">否</el-radio>
        </template>
      </el-table-column>
      <el-table-column prop="categoryId" label="所属抽屉" width="80">
        <template slot-scope="scope">
          <span>{{scope.row.categoryId}}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="80">
        <template slot-scope="scope">
          <el-button @click="saveInfo(scope.row)" type="primary" size="small">保存</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>

<script>
export default {
  name: 'ExerciseMain',
  props: {
    elist: Array
  },
  data () {
    return {
      tableData: [],
      multipleSelection: []
    }
  },
  watch: {
    elist: {
      handler (newVal) {
        this.tableData = newVal
      },
      deep: true
    }
  },
  mounted () {
    this.tableData = this.elist
  },
  methods: {
    handleChange (row) {
      this.$set(row, 'watched', '2')
      this.$emit('elistChange', row)
      this.$emit('getSaveList', this.multipleSelection)
    },
    saveInfo (row) {
      let uname = localStorage.getItem('uname')
      this.$http.post('/exercise/update_exercise_id.php', [row, uname]).then(res => {
        this.$message({ message: '保存成功！！', type: 'success' })
        this.handleChange(row)
      })
    },
    jumpto (row) {
      let uname = localStorage.getItem('uname')
      let url = row.tid.length > 8 ? 'http://emp.willclass.com/basic/newExerciseData/detail?exerciseId=' + row.tid : 'http://newopen.willclass.com/emp-exercise-detail?exerciseId=' + row.tid + '&isAlternateExercise=0&subjectId=2&isIntroduce=1'
      window.open(url, 'watch')
      this.$set(row, 'watched', '2')
      this.$http.post('/exercise/update_exercise_id.php', [row, uname])
      this.toggleSelection([row])
    },
    toggleSelection (rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    }
  }
}
</script>

<style>
  .exercisemain .radio{
    margin: 0px;
    color: #000;
  }
  .exercisemain a{
    cursor: pointer;
    color: #000;
  }
  .exercisemain a.watched{
    color: green;
  }
</style>
