<template>
  <tr class="exerciseitem">
    <td><a :href=href target="blank">{{tid}}</a></td>
    <td>{{eitem.quality}}</td>
    <td>
      <input type="radio" :name="'type'+tid" :id="1+tid" value="1" v-model="eitem.type">
      <label :for="1+tid">单选题</label>
      <input type="radio" :name="'type'+tid" :id="2+tid" value="2" v-model="eitem.type">
      <label :for="2+tid">填空题</label>
      <input type="radio" :name="'type'+tid" :id="3+tid" value="3" v-model="eitem.type">
      <label :for="3+tid">解答题</label>
    </td>
    <td>
      <input type="radio" :name="'du'+tid" :id="1+tid" value="1" v-model="eitem.remark">
      <label :for="1+tid">是</label>
      <input type="radio" :name="'du'+tid" :id="2+tid" value="2" v-model="eitem.remark">
      <label :for="2+tid">否</label>
    </td>
    <td>
      <input type="radio" :name="'un'+tid" :id="3+tid" value="1" v-model = "eitem.unusual">
      <label :for="3+tid">是</label>
      <input type="radio" :name="'un'+tid" :id="4+tid" value="2" v-model = "eitem.unusual">
      <label :for="4+tid">否</label>
    </td>
    <td>
      <textarea v-model="eitem.marks"></textarea>
    </td>
    <td>
      <input type="radio" :name="'isD'+tid" :id="5+tid" value="1" v-model = "item.isDemo">
      <label :for="5+tid">是</label>
      <input type="radio" :name="'isD'+tid" :id="6+tid" value="2" v-model = "item.isDemo">
      <label :for="6+tid">否</label>
    </td>
    <td class="op"><span @click="update">保存</span></td>
    <td><span>确认抽屉后由管理员添加！！！</span></td>
  </tr>
</template>

<script>
export default {
  name: 'ExerciseItem',
  props: {
    item: Object,
    index: Number
  },
  data () {
    return {
      eitem: this.item,
      href: 'http://emp.willclass.com/basic/newExerciseData/detail?exerciseId=' + this.item.tid
    }
  },
  watch: {
    eitem: {
      deep: true,
      handler () {
        this.$emit('itemChange', [this.eitem, this.index])
      }
    }
  },
  computed: {
    tid () {
      let str = this.eitem.watched === '2' ? '☑' : ''
      return this.eitem.tid + str
    }
  },
  methods: {
    update () {
      const uname = localStorage.getItem('uname')
      this.$http.put('exercise/update_exercise_id.php', [this.eitem, uname]).then(res => {
        console.log(this.item)
        if (res.data.code === 200) {
          this.$message({
            message: '保存成功！！！',
            type: 'success'
          })
        }
      })
    }
  }
}
</script>

<style>
  textarea{
    width: 100%;
    font-size: 16px;
  }
  .exerciseitem .op>span{
    display: inline-block;
    padding: 3px 8px;
    background: #108EE9;
    color: #FFF;
    border-radius: 5px;
    margin: 5px;
    cursor: pointer;
  }
  label{
    margin-right: 10px;
  }
  .exerciseitem{
    background: #FFFFFF;
  }
  .exerciseitem:hover{
    background: #ECF6FD;
  }
  a{
    text-decoration: none;
  }
</style>
