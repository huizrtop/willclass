<template>
  <div class="leftbox">
    <kn-box :klist = 'klist' @delkn = 'delkn' @search = "search"></kn-box>
    <auto-complete @addKn="addKn"></auto-complete>
  </div>
</template>

<script>

import AutoComplete from '@/components/public/autocomplete/AutoComplete.vue'
import KnBox from './KnBox'

export default {
  name: 'TopBox',
  components: {
    AutoComplete,
    KnBox
  },
  data () {
    return {
      klist: []
    }
  },
  methods: {
    addKn (val) {
      this.klist.push(val)
    },
    delkn (index) {
      this.klist.splice(index, 1)
    },
    search (val) {
      this.$emit('countShow', val)
    }
  },
  watch: {
    klist () {
      localStorage.setItem('klist', this.klist)
      if (this.klist.length === 0) {
        this.$emit('emptydata')
      }
    }
  },
  mounted () {
    // this.klist = localStorage.getItem('klist')
    if (localStorage.getItem('klist').split(',')[0] !== '') {
      this.klist = localStorage.getItem('klist').split(',')
    }
  }
}
</script>

<style scoped>
  .leftbox{
    width: 550px;
    border-right: 2px dashed green;
  }
</style>
