<template>
    <div>
      <hr>
      <div class="exercisesel">
        <span>题目筛选：</span>
        <input type="radio" name="watch1" id="watch00" value="0" v-model = "sel.watched">
        <label for="watch00">所有题目</label>
        <input type="radio" name="watch1" id="watched2" value="2" v-model = "sel.watched">
        <label for="watched2">看过的题目</label>
        <input type="radio" name="watch1" id="watch1" value="1" v-model = "sel.watched">
        <label for="watch1">没有看过的题目</label>
        <span>备注筛选：</span>
        <textarea v-model="sel.mark"></textarea>
        <span>&nbsp;&nbsp;&nbsp;&nbsp;抽屉筛选：</span>
        <textarea v-model="sel.category"></textarea>
      </div>
      <hr>
      <table class="exercisebox" v-if="seldata.length !== 0">
        <thead><table-head></table-head></thead>
        <tbody>
          <exercise-item v-for="(item, index) in seldata" :key = item.id :item = "item" :index = "index" @itemChange = "handleItemChange"></exercise-item>
        </tbody>
      </table>
      <div v-else class="noexercise">没有符合条件的题目！！请尝试修改筛选条件！！</div>
    </div>
</template>

<script>
import TableHead from './TableHead.vue'
import ExerciseItem from './ExerciseItem.vue'
export default {
  name: 'ExerciseBox',
  props: {
    elist: Array
  },
  data () {
    return {
      elistdata: this.elist,
      seldata: this.elist,
      sel: {
        watched: 0,
        mark: '',
        category: ''
      }
    }
  },
  components: {
    TableHead,
    ExerciseItem
  },
  methods: {
    handleItemChange (val) {
      this.elistdata[val[1]] = val[0]
    },
    filter (data) {
      let result = true
      if (parseInt(this.sel.watched) !== 0) {
        result = parseInt(this.sel.watched) === parseInt(data.watched)
      }
      if (this.sel.mark !== '') {
        let word = '.*' + this.sel.mark + '.*'
        let reg = new RegExp(word)
        result = reg.test(data.marks)
      }
      if (this.sel.category !== '') {
        let word = '.*' + this.sel.category + '.*'
        let reg = new RegExp(word)
        result = reg.test(data.category)
      }
      return result
    }
  },
  watch: {
    sel: {
      deep: true,
      handler () {
        this.seldata = this.elistdata.filter(data => this.filter(data))
      }
    }
  }
}
</script>

<style>
  .exercisebox, .exercisebox th, .exercisebox td{
    border: 1px solid #808080;
    border-collapse:collapse;
    padding: 2px 8px;
    text-align: center;
  }
  .exercisebox{
    margin-top: 5px;
  }
  .exercisesel textarea{
    width: 300px;
    vertical-align: -webkit-baseline-middle;
  }
  .noexercise{
    color: red;
  }
</style>
