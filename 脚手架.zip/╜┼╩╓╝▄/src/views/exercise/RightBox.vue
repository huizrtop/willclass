<template>
  <div class="right-box">
    <p>
      <input type="radio" name="watch" id="watch0" value="0" v-model = "watched">
      <label for="watch0">所有题目</label>
      <input type="radio" name="watch" id="watched" value="2" v-model = "watched">
      <label for="watched">只看看过的题目</label>
      <input type="radio" name="watch" id="watch" value="1" v-model = "watched">
      <label for="watch">只看没有看过的题目</label>
    </p>
    <hr>
    <div class="txt" v-if="count.total != 0">
      该知识点组合下共有：<span>{{count.total}}</span>个；
      其中，题目质量为高的有：<span>{{count.g}}</span>个；
      题目质量为较高的有：<span>{{count.j}}</span>个；
      题目质量为一般的有：<span>{{count.y}}</span>个
    </div>
    <div class="txt" v-else><span>该知识点组合下没有题目，请尝试其他知识点组合！！！！</span></div>
    <hr>
    <div class="searbtn" v-if="count.total != 0">
      <span @click="searchList(count.id, count.total)">取出所有题目</span>
      <span v-if="count.total >= 200" @click="searchList(count.id, 200)">取出200个题目</span>
      <span v-if="count.total >= 150" @click="searchList(count.id, 150)">取出150个题目</span>
      <span v-if="count.total >= 100" @click="searchList(count.id, 100)">取出100个题目</span>
      <span v-if="count.total >= 50"  @click="searchList(count.id, 50)">取出50个题目</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'RightBox',
  props: {
    ecount: Object
  },
  data () {
    return {
      watched: 0,
      count: this.ecount
    }
  },
  watch: {
    watched () {
      this.$http.post('exercise/get_exercise_list_id_count.php', [this.count.id.split('#'), this.watched]).then(res => {
        this.count = res.data
      })
    }
  },
  methods: {
    searchList (id, c) {
      this.$http.post('exercise/get_exercise_list_id.php', [id, c, this.watched]).then(res => {
        this.$emit('elist', res.data)
        this.$message({
          message: '取题成功，可以开始看题啦！！！',
          type: 'success'
        })
      })
    }
  }
}
</script>

<style>
  .right-box{
    margin-left: 10px;
    width: 70%;
  }
  .right-box>.txt,.right-box>.txt>span,.right-box>.searbtn{
    padding: 5px;
  }
  .right-box>.txt>span{
    color: red;
  }
  .right-box>.searbtn>span{
    display: inline-block;
    padding: 3px 8px;
    background: #108EE9;
    color: #FFF;
    border-radius: 5px;
    margin: 5px;
    cursor: pointer;
  }
</style>
