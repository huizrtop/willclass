<template>
  <tr class="tablehead">
    <th>题目ID</th>
    <th>题目质量</th>
    <th>题目类型</th>
    <th>是否重题</th>
    <th>是否异常</th>
    <th>备注</th>
    <th>是否样题</th>
    <th>操作</th>
    <th>所属抽屉</th>
  </tr>
</template>

<script>
export default {
  name: 'TableHead'
}
</script>

<style>
  .tablehead{
    height: 40px;
    background: #F7F7F7;
    font-size: 16px;
  }
  .tablehead th:first-child{
    width: 150px;
  }
  .tablehead th:nth-child(6){
    width: 400px;
  }
  .tablehead th:nth-child(8){
    width: 100px;
  }
  .tablehead th:nth-child(9){
    width: 250px;
  }
</style>
