<template>
  <div class="exercise">
    <top-box @elist = "getelist" @clearTable = "clearTable"></top-box>
    <hr>
    <div  v-if="elist.length !== 0" class="exercisebody">
      <el-button type="primary" round v-if="!isStart" @click="startw">开始看题</el-button>
      <el-button type="info" round v-else>看题中</el-button>
      <exercise-box :elist = "elist" v-if="isStart"></exercise-box>
      <p v-else>已经取出 {{elist.length}} 个题目，请点击“开始看题”</p>
    </div>
  </div>
</template>

<script>
import TopBox from './TopBox.vue'
import ExerciseBox from './ExerciseBox.vue'
export default {
  name: 'Exercise',
  components: {
    TopBox,
    ExerciseBox
  },
  data () {
    return {
      elist: [],
      isStart: false
    }
  },
  methods: {
    getelist (val) {
      this.elist = val
    },
    startw () {
      this.$message({
        message: '题目加载中`～`',
        type: 'info'
      })
      let token = localStorage.getItem('token')
      let uname = localStorage.getItem('uname')
      let list = this.elist.map(item => item.tid)
      this.$http.post('exercise/storage.php', [list, token, uname]).then(res => {
        if (res.data.code === 200) {
          this.isStart = true
        }
      })
    },
    clearTable () {
      this.elist = []
      this.isStart = false
    }
  },
  watch: {
    elist () {
      this.isStart = false
    }
  },
  beforeCreate () {
    let token = localStorage.getItem('token')
    if (!token) {
      this.$router.push({ path: '/login' })
    }
  },
  beforeMount () {
    let token = localStorage.getItem('token')
    let uname = localStorage.getItem('uname')
    if (token && localStorage.getItem('klist').split(',')[0] !== '') {
      this.$http.post('exercise/get_exercise_token.php', uname).then(res => {
        this.elist = res.data
        this.isStart = true
      })
    }
  }
}
</script>

<style>
  .exercisebody{
    text-align: center;
  }
  .exercisebody p{
    color: red;
  }
</style>
