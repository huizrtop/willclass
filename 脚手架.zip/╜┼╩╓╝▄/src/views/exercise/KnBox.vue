<template>
  <div class="knbox">
    <p>已经选中的知识点有（点击可删除）:<span class="search" @click="handleSearch" v-if="klist.length !== 0">点击搜题</span></p>
    <span v-for="(item, index) in klist" :key='item.slice(-12)' @click="handleClick(index)">{{item.slice(0,-12)}}</span>
  </div>
</template>

<script>
export default {
  name: 'KnBox',
  props: {
    klist: Array
  },
  methods: {
    handleClick (index) {
      this.$emit('delkn', index)
    },
    handleSearch () {
      let list = this.klist.map(item => item.slice(-12))
      let watched = 0
      this.$http.post('exercise/get_exercise_list_id_count.php', [list, watched]).then(res => {
        this.$emit('search', res.data)
      })
    }
  },
  watch: {
    klist () {
      if (this.klist.length !== 0) {
        this.handleSearch()
      }
    }
  }
}
</script>

<style>
  .knbox>span, .knbox .search{
    display: inline-block;
    padding: 3px 8px;
    background: #108EE9;
    color: #FFF;
    border-radius: 5px;
    margin: 5px;
    cursor: pointer;
  }
</style>
