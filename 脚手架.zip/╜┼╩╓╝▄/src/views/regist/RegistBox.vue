
<template>
  <div>
    <div class="regist-box">
      <form-title>  Wellcome to Regist </form-title>
      <hr>
      <form-item id="uname" :udata="formdata.duname" msg="input user name please" @change="changeUname"><span slot="txt" class="txt">user name: </span></form-item>
      <form-item id="upwd" :udata="formdata.dupwd" msg="input password please" @change="changeUpwd" type = "password"><span slot="txt" class="txt">password: </span></form-item>
      <div>
        <form-btn class="regist" @handleClick="handleReg">Regist</form-btn>
        <form-btn class="login" @handleClick="handleLogin()">Login</form-btn>
      </div>
    </div>
  </div>
</template>
<script>
import FormTitle from '../login/FormTitle.vue'
import FormItem from '../login/FormItem.vue'
import FormBtn from '../login/FormBtn.vue'

export default {
  name: 'RegistBox',
  components: { FormTitle, FormItem, FormBtn },
  data () {
    return {
      formdata: {
        duname: '',
        dupwd: ''
      }
    }
  },
  methods: {
    changeUname (val) {
      this.formdata.duname = val
      this.$http.post('regist/valiuname.php', this.formdata).then(res => {
        let data = parseInt(JSON.parse(res.data.data).data)
        if (data === 1) {
          this.$message({ message: '用户名已存在！！！', type: 'warning' })
        } else {
          this.$message({ message: '服务器错误！！！', type: 'error' })
        }
      })
    },
    changeUpwd (val) {
      this.formdata.dupwd = val
    },
    handleReg () {
      if (this.formdata.duname === '' || this.formdata.dupwd === '') {
        this.$message({ message: '用户名或密码不能为空！！！', type: 'warning' })
      } else {
        this.$http.post('regist/regist.php', this.formdata).then(res => {
          let data = parseInt(JSON.parse(res.data.data).data)
          if (data === 1) {
            this.$message({ message: '用户名已存在！！！', type: 'warning' })
          } else if (data === 2) {
            this.$message({ message: '注册成功！！！', type: 'success' })
            localStorage.setItem('token', res.data.token)
            localStorage.setItem('uname', res.data.uname)
            this.$router.push({ path: '/home' })
          } else {
            this.$message({ message: '服务器错误！！！', type: 'error' })
          }
        })
      }
    },
    handleLogin () {
      this.$router.push({ name: 'login' })
    }
  }
}
</script>

<style scoped>
  .regist-box{
    width: 400px;
    height: 300px;
    background: #ffffff;
    position: absolute;
    left: 0px;
    right: 0px;
    top: 0px;
    bottom: 0px;
    margin: auto;
    border-radius: 5px;
    border: 1px solid #f6d6f6;
    padding: 10px;
  }
  .regist{
    bottom: -25px;
    background: #108EE9;
  }
  .regist:active{
    background: #0188FB;
  }
  .login{
    bottom: -40px;
    background: #C20C0C;
  }
  .login:active{
    background: #9B0909;
  }
</style>
