<template>
  <div><regist-box></regist-box></div>
</template>

<script>
import RegistBox from './RegistBox.vue'
export default {
  name: 'Regist',
  components: { RegistBox }
}
</script>
