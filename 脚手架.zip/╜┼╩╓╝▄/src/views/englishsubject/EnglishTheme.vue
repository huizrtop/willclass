<template>
  <div>
    <el-dialog title="英语题材维护" :visible.sync="dialogFormVisible">
  <el-form :model="form">
    <el-form-item label="题材名称" :label-width="formLabelWidth">
      <el-input v-model="form.themeName" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="状态" :label-width="formLabelWidth">
      <el-select v-model="form.status" placeholder="请选择题材状态">
        <el-option label="使用" value="1"></el-option>
        <el-option label="禁用" value="2"></el-option>
      </el-select>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="dialogFormVisible = false">取 消</el-button>
    <el-button type="primary" @click="handleConfirm">确 定</el-button>
  </div>
</el-dialog>
    <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>英语题材维护</span>
      <el-button style="float: right; padding: 5px 10px" type="primary" @click="handleAdd(info,1)">添加同级题材</el-button>
    </div>
    <div class="text item">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item v-for="item in crumb" :key="item.id">{{item.themeName}}</el-breadcrumb-item>
      </el-breadcrumb>
      <el-button type='text' @click="getThemeList(crumb[crumb.length-1].id)" v-if="crumb.length !== 0">返回上级</el-button>
    </div>
    <hr>
    <div class="text item">
      <el-table :data="tableData" style="width: 100%;margin-bottom: 20px;" border stripe>
        <el-table-column type="index" width="50"></el-table-column>
        <el-table-column prop="id" label="ID" width = "120"></el-table-column>
        <el-table-column prop="themeName" label="题材名称" show-overflow-tooltip></el-table-column>
        <el-table-column prop="searchIndex" label="索引" width="150"></el-table-column>
        <el-table-column prop="status" label="状态" width="120">
          <template slot-scope="scope">
            <span v-if="scope.row.status === '1'">使用中</span>
            <span v-if="scope.row.status === '2'">已禁用</span>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="操作" width="200">
          <template slot-scope="scope">
            <el-button @click="handleAdd(scope.row,3)" type="primary" size="small">修改</el-button>
            <el-button @click="handleAdd(scope.row,2)" type="success" size="small" v-if="scope.row.children === 0  && scope.row.status === '1'">添加子级</el-button>
            <el-button @click="getThemeList(scope.row.id)" type="info" size="small" v-if="scope.row.children === 1 && scope.row.status === '1'">查看子级</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </el-card>
  </div>
</template>

<script>
export default {
  name: 'EnglishTheme',
  data () {
    return {
      tableData: [],
      info: [],
      crumb: [],
      dialogFormVisible: false,
      form: {},
      formLabelWidth: '120px',
      clickType: 0
    }
  },
  methods: {
    getThemeList (fid) {
      this.$http.post('/english/englishtheme/getTheme.php', fid).then(res => {
        this.tableData = res.data.tableData
        this.info = res.data.info
        this.crumb = res.data.crumb
      })
    },
    handleConfirm () {
      this.dialogFormVisible = false
      if (this.clickType === 1 || this.clickType === 2) {
        this.$http.post('/english/englishtheme/add_theme.php', [this.form, this.clickType]).then(res => {
          if (res.data.code === 200) {
            this.$message({ message: '添加成功', type: 'success' })
            this.getThemeList(this.form.fatherId)
          }
        })
      } else if (this.clickType === 3) {
        this.$http.post('/english/englishtheme/update_theme.php', this.form).then(res => {
          if (res.data.code === 200) {
            this.$message({ message: '修改成功', type: 'success' })
            this.getThemeList(this.form.fatherId)
          }
        })
      }
    },
    handleAdd (inf, type) {
      this.dialogFormVisible = true
      this.clickType = type
      if (type === 1) {
        this.form = inf
      } else if (type === 2) {
        this.form = inf
        this.form.fatherId = inf.id
        this.form.themeName = ''
      } else if (type === 3) {
        this.form = inf
      }
    }
  },
  mounted () {
    this.getThemeList('')
  }
}
</script>

<style>

</style>
