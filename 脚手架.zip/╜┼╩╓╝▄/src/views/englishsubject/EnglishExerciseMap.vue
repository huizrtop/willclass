<template>
  <el-card class="box-card">
  <div slot="header" class="clearfix">
    <span>英语题目总览</span>
  </div>
  <div class="text item">
    句子改错
  </div>
  <div class="text item">
    <el-table :data="tableData" style="width: 100%;margin-bottom: 20px;" row-key="id" border :tree-props="{children: 'children', hasChildren: 'hasChildren'}">
      <el-table-column type="index" width="50"></el-table-column>
      <el-table-column prop="kn" label="知识点名称"></el-table-column>
      <el-table-column prop="type" label="知识点类型（是否为主要知识点）"></el-table-column>
      <el-table-column prop="count" label="所含题目数量" width="120"></el-table-column>
      <el-table-column prop="countWatched" label="看过题目数量" width="120"></el-table-column>
    </el-table>
  </div>
  <div class="text item">
    单项选择
  </div>
  <div class="text item">
    <el-table :data="tableData1" style="width: 100%;margin-bottom: 20px;" row-key="id" border :tree-props="{children: 'children', hasChildren: 'hasChildren'}">
      <el-table-column type="index" width="50"></el-table-column>
      <el-table-column prop="kn" label="知识点名称"></el-table-column>
      <el-table-column prop="type" label="知识点类型（是否为主要知识点）"></el-table-column>
      <el-table-column prop="count" label="所含题目数量" width="120"></el-table-column>
      <el-table-column prop="countWatched" label="看过题目数量" width="120"></el-table-column>
    </el-table>
  </div>
</el-card>
</template>

<script>
export default {
  name: 'EnglishExerciseMap',
  data () {
    return {
      tableData: [],
      tableData1: []
    }
  },
  mounted () {
    this.$message({ message: '正在加载知识点和题目信息～', type: 'warning' })
    this.$http.post('/english/get_english_exercise_map.php', '句子改错').then(res => {
      this.tableData = res.data
    })
    this.$http.post('/english/get_english_exercise_map.php', '单项选择').then(res => {
      this.tableData1 = res.data
      this.$message({ message: '信息加载成功～', type: 'success' })
    })
  }
}
</script>

<style>

</style>
