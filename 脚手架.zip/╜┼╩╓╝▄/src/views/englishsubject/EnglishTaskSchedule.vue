<template>
  <el-card class="box-card">
  <div slot="header" class="clearfix">
    <span>英语任务总览</span>
  </div>
  <div class="text item" v-if="show2">英语阅读理解洗题任务<hr></div>
  <div class="text item" v-if="show2">
    <el-table :data="tableData1" style="width: 100%;margin-bottom: 20px;" border stripe>
      <el-table-column type="index" width="50"></el-table-column>
      <el-table-column prop="maink" label="题目类型"></el-table-column>
      <el-table-column prop="tcount" label="所含题目数量" width="120"></el-table-column>
      <el-table-column prop="countWatched" label="看过题目数量" width="120"></el-table-column>
      <el-table-column prop="status" label="状态" width="120">
        <template slot-scope="scope">
          <span v-if="scope.row.status === '4'">未处理</span>
          <span v-if="scope.row.status === '5'">处理中</span>
          <span v-if="scope.row.status === '6'">已完成</span>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="220">
        <template slot-scope="scope">
          <el-button @click="handleClick(scope.row)" type="primary" size="small" v-if="scope.row.status === '4'">开始看题</el-button>
          <el-button @click="handleClick(scope.row)" type="success" size="small" v-if="scope.row.status === '5'">继续看题</el-button>
          <el-button @click="handleFinish(scope.row)" type="warning" size="small" v-if="scope.row.status === '5'">看题完毕</el-button>
          <el-button type="info" size="small" v-if="scope.row.status === '6'" @click="handleClick(scope.row)" >重新看题</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
  <div class="text item" v-if="show1">
    <span v-if="kn.tcount !== '0'">当前正在处理的主要知识点为：{{kn.mainknowledge}}，<br>这个主要知识点含有 {{kn.tcount}} 个题目，已看 {{kn.countWatched}} 个题目，未看 {{kn.tcount - kn.countWatched}} 个题目</span>
    <span v-else>目前暂时没有正在处理的知识点</span>
     <el-button style="float: right; padding: 3px 0" type="text" v-if="kn.tcount !== '0'" @click="handleClick(kn)">继续看题</el-button>
     <hr>
  </div>
  <div class="text item" v-if="show1">
    需要处理的总的主要知识点数为：{{count.total}}，已看过的主要知识点数为{{count.deal}}，正在看的主要知识点数为{{count.dealing}}，还未看的主要知识点数为{{count.undeal}}
     <hr>
  </div>
  <div class="text item" v-if="show1">
    <el-table :data="tableData" style="width: 100%;margin-bottom: 20px;" border stripe>
      <el-table-column type="index" width="50"></el-table-column>
      <el-table-column prop="mainknowledge" label="知识点名称"></el-table-column>
      <el-table-column prop="type" label="知识点类型（是否为主要知识点）"></el-table-column>
      <el-table-column prop="tcount" label="所含题目数量" width="120"></el-table-column>
      <el-table-column prop="countWatched" label="看过题目数量" width="120"></el-table-column>
      <el-table-column prop="status" label="状态" width="120">
        <template slot-scope="scope">
          <span v-if="scope.row.status === '1'">未处理</span>
          <span v-if="scope.row.status === '2'">处理中</span>
          <span v-if="scope.row.status === '3'">已完成</span>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作" width="220">
        <template slot-scope="scope">
          <el-button @click="handleClick(scope.row)" type="primary" size="small" v-if="scope.row.status === '1'">开始看题</el-button>
          <el-button @click="handleClick(scope.row)" type="success" size="small" v-if="scope.row.status === '2'">继续看题</el-button>
          <el-button @click="handleFinish(scope.row)" type="warning" size="small" v-if="scope.row.status === '2'">看题完毕</el-button>
          <el-button type="info" size="small" v-if="scope.row.status === '3'" @click="handleClick(scope.row)" >重新看题</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</el-card>
</template>

<script>
export default {
  name: 'EnglishTaskSchedule',
  data () {
    return {
      tableData: [],
      tableData1: [],
      count: [],
      kn: [],
      uname: '',
      show1: false,
      show2: false
    }
  },
  methods: {
    handleClick (row) {
      if (row.status === '2' || row.status === 2) {
        sessionStorage.enknlist = row.mainknowledge
        sessionStorage.type = row.type
        sessionStorage.count = row.tcount
        this.$router.push({ name: 'en_exercise' })
      } else if (row.status === '1' || row.status === '3') {
        this.$http.get('/english/get_english_status_3.php').then(res => {
          if (res.data >= 1) {
            this.$message({ message: '您还有尚未处理完毕的知识点，暂时不能开启新的知识点！！！', type: 'warning' })
          } else {
            this.$http.post('/english/beginTask.php', row.mainknowledge).then(res => {
              sessionStorage.enknlist = row.mainknowledge
              sessionStorage.type = row.type
              sessionStorage.count = row.tcount
              this.$router.push({ name: 'en_exercise' })
            })
          }
        })
      } else if (row.status === '4' || row.status === '6' || row.status === '5') {
        this.$http.post('/english/reading/beginTask.php', row.id).then(res => {
          sessionStorage.ttype = row.maink
          sessionStorage.task_id = row.id
          sessionStorage.count = row.tcount
          this.$router.push({ name: 'en_reading' })
        })
      }
    },
    getTaskList () {
      this.$http.get('/english/get_english_task.php').then(res => {
        this.tableData = res.data.tableData
        this.count = res.data.count
        this.kn = res.data.kn
      })
    },
    getTaskList1 () {
      this.$http.get('/english/reading/get_english_task_reading.php').then(res => {
        this.tableData1 = res.data
      })
    },
    handleFinish (row) {
      let r = confirm('是否确认看题完毕')
      if (r) {
        if (row.status === '2') {
          this.$http.post('/english/english_task_finish.php', row.mainknowledge).then(res => {
            if (parseInt(res.data.code) === 200) {
              this.$message({ message: '保存成功', type: 'success' })
              this.getTaskList()
            }
          })
        } else if (row.status === '2') {
          this.$http.post('/english/reading/english_task_finish.php', row.id).then(res => {
            if (parseInt(res.data.code) === 200) {
              this.$message({ message: '保存成功', type: 'success' })
              this.getTaskList()
            }
          })
        }
      }
    }
  },
  mounted () {
    this.getTaskList()
    this.getTaskList1()
    this.uname = localStorage.getItem('uname')
    if (this.uname === 'admin' || this.uname === '13693599859') {
      this.show1 = true
      this.show2 = true
    }
    if (this.uname === 'admin' || this.uname === 'zhuangmeihua') {
      this.show2 = true
    }
  }
}
</script>

<style>

</style>
