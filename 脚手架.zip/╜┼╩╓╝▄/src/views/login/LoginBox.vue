<template>
  <div>
    <div class="login-box">
      <form-title>  Wellcome to login </form-title>
      <hr>
      <form-item id="uname" :udata="formdata.duname" msg="input user name please" @change="changeUname"><span slot="txt" class="txt">user name: </span></form-item>
      <form-item id="upwd" :udata="formdata.dupwd" msg="input password please" @change="changeUpwd" type = "password" @keyup.enter="handleLogin"><span slot="txt" class="txt">password: </span></form-item>
      <div>
        <form-btn class="login" @handleClick="handleLogin()">Login</form-btn>
        <form-btn class="regist" @handleClick="handleReg">Regist</form-btn>
      </div>
    </div>
  </div>
</template>
<script>
import FormTitle from './FormTitle.vue'
import FormItem from './FormItem.vue'
import FormBtn from './FormBtn.vue'

export default {
  name: 'LoginBox',
  components: { FormTitle, FormItem, FormBtn },
  data () {
    return {
      formdata: {
        duname: '',
        dupwd: ''
      }
    }
  },
  methods: {
    changeUname (val) {
      this.formdata.duname = val
    },
    changeUpwd (val) {
      this.formdata.dupwd = val
    },
    handleLogin () {
      if (this.formdata.duname === '' || this.formdata.dupwd === '') {
        this.$message({ message: '用户名或密码不能为空！！！', type: 'warning' })
      } else {
        this.$http.post('login/login.php', this.formdata).then(res => {
          let data = parseInt(JSON.parse(res.data.data).data)
          if (data === 1) {
            this.$message({ message: '用户名或密码错误！！！', type: 'warning' })
          } else if (data === 2) {
            this.$message({ message: '登录成功！！！', type: 'success' })
            localStorage.setItem('token', res.data.token)
            localStorage.setItem('uname', res.data.uname)
            this.$router.push({ path: '/home' })
          } else {
            this.$message({ message: '服务器错误！！！', type: 'warning' })
          }
        })
      }
    },
    handleReg () {
      this.$router.push({ name: 'regist' })
    }
  }
}
</script>

<style scoped>
  .login-box{
    width: 400px;
    height: 300px;
    background: #ffffff;
    position: absolute;
    left: 0px;
    right: 0px;
    top: 0px;
    bottom: 0px;
    margin: auto;
    border-radius: 5px;
    border: 1px solid #f6d6f6;
    padding: 10px;
  }
  .login{
    bottom: -25px;
    background: #108EE9;
  }
  .login:active{
    background: #0188FB;
  }
  .regist{
    bottom: -40px;
    background: #C20C0C;
  }
  .regist:active{
    background: #9B0909;
  }
</style>
