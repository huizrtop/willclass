<template>
  <div><login-box></login-box></div>
</template>

<script>
import LoginBox from './LoginBox'
export default {
  name: 'Login',
  components: { LoginBox }
}
</script>
