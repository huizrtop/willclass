<template>
  <div class="form-btn" @click="$emit('handleClick')">
   <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'FormBtn'
}
</script>

<style scoped>
  .form-btn{
    width: 100%;
    height: 40px;
    line-height: 40px;
    border-radius: 5px;
    text-align: center;
    font-size: 20px;
    cursor: pointer;
    position: relative;
  }
</style>
