<template>
  <div class="form-item">
   <label :for="id">
     <slot name="txt"></slot>
     <input :type="type" :id="id" :value="udata" :placeholder="msg" @input="inputChange">
     <span class="icon"><slot name="icon"></slot></span>
   </label>
  </div>
</template>

<script>
export default {
  name: 'FormItem',
  props: {
    id: String,
    udata: String,
    msg: String,
    type: {
      type: String,
      default: 'text'
    }
  },
  methods: {
    inputChange (event) {
      this.$emit('change', event.target.value)
    }
  }
}
</script>

<style scoped>
  .form-item{
    width: 100%;
    height: 60px;
    line-height: 60px;
    text-align: left;
    font-size: 16px;
  }
  .form-item input{
    display: inline-block;
    width: 220px;
    height: 20px;
    line-height: 28px;
    border-radius: 3px;
    padding: 4px;
    outline: none;
    border: 1px solid #cccccc;
    font-size: 14px;
    margin-left: 10px;
  }
  .form-item span.txt{
    display: inline-block;
    width: 100px;
    text-align: right;
  }
</style>
