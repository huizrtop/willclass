<template>
  <div class="home">
    <el-container class="container">
      <el-header class="header">
        <el-row>
          <el-col :span="20"><div class="grid-content bg-purple"><h2>Wellcome</h2></div></el-col>
          <el-col :span="4"><div class="grid-content bg-purple-light"><el-button style="float: right; padding: 20px 10px" type="text" @click="loginOut">退出登录</el-button></div></el-col>
        </el-row>
      </el-header>
      <el-container>
        <el-aside class="aside" width="200px">
          <el-menu :router = "true" :unique-opened="true">
            <el-submenu index="1" v-if="math">
              <template slot="title">
                <i class="el-icon-location"></i>
                <span>任务中心</span>
              </template>
                <el-menu-item index="/home">
                  <i class="el-icon-menu"></i>
                  <span>我的任务</span>
                </el-menu-item>
                <el-menu-item index="/home/myschedule">
                  <i class="el-icon-menu"></i>
                  <span>任务进度</span>
                </el-menu-item>
                <el-menu-item index="/home/finishregist">
                  <i class="el-icon-menu"></i>
                  <span>完成登记</span>
                </el-menu-item>
            </el-submenu>
            <el-submenu index="2" v-if='taskManageVisible'>
              <template slot="title">
                <i class="el-icon-location"></i>
                <span>任务管理</span>
              </template>
                <el-menu-item index="/home/taskasign">
                  <i class="el-icon-menu"></i>
                  <span>任务分配</span>
                </el-menu-item>
                <el-menu-item index="/home/taskschedule">
                  <i class="el-icon-menu"></i>
                  <span>进度管理</span>
                </el-menu-item>
                <el-menu-item index="2-3">
                  <i class="el-icon-menu"></i>
                  <span>工作纪要</span>
                </el-menu-item>
            </el-submenu>
            <el-submenu index="3" v-if="english">
              <template slot="title">
                <i class="el-icon-location"></i>
                <span>英语学科</span>
              </template>
                <el-menu-item index="/home/englishtaskschedule">
                  <i class="el-icon-menu"></i>
                  <span>任务总览</span>
                </el-menu-item>
                <el-menu-item index="/home/englishexercisemap">
                  <i class="el-icon-menu"></i>
                  <span>题目总览</span>
                </el-menu-item>
                <el-menu-item index="/home/englishknowledge">
                  <i class="el-icon-menu"></i>
                  <span>知识点概览</span>
                </el-menu-item>
                <el-menu-item index="/home/englishtheme">
                  <i class="el-icon-menu"></i>
                  <span>英语题材维护</span>
                </el-menu-item>
            </el-submenu>
            <el-submenu index="4" v-if="math">
              <template slot="title">
                <i class="el-icon-location"></i>
                <span>数学学科</span>
              </template>
                <el-menu-item index="/home/mathknowledge">
                  <i class="el-icon-menu"></i>
                  <span>知识点概览</span>
                </el-menu-item>
            </el-submenu>
          </el-menu>
        </el-aside>
        <el-main class="main">
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>

export default {
  name: 'home',
  data () {
    return {
      taskManageVisible: false,
      english: false,
      math: false
    }
  },
  methods: {
    loginOut () {
      localStorage.clear()
      this.$router.push({ name: 'login' })
    }
  },
  beforeCreate () {
    const token = localStorage.getItem('token')
    if (!token) {
      this.$router.push({ name: 'login' })
    }
  },
  mounted () {
    const uname = localStorage.getItem('uname')
    this.$http.post('/english/get_user_grade.php', uname).then(res => {
      if (res.data === 6) {
        this.english = true
        this.$router.push({ name: 'englishtaskschedule' })
      }
      if (res.data === 1) {
        this.math = true
      }
    })
    if (uname === 'admin') {
      this.taskManageVisible = true
      this.english = true
      this.math = true
    }
  }
}
</script>
<style scoped>
.home .container {
  height: 100%;
}
.home .header {
  background-color: #b3c0d1;
  text-align: center;
  line-height: 60px;
}
.home .aside {
  background-color: #d3dce6;
}
.home .main {
  background-color: #e9eef3;
  height: 100%;
}
</style>
