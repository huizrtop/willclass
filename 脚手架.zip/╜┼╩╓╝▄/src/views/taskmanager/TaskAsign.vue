<template>
  <el-card class="box-card">
  <div slot="header" class="clearfix">
      <span>任务指派</span>
      <el-button style="float: right; padding: 3px 0" type="text">查看总进度</el-button>
  </div>
  <div class="text item">
    <el-input placeholder="请输入内容" v-model="uid" clearable></el-input>
    <el-button type="primary" size="small" @click="handleClick">指派</el-button>
  </div>
  <div class=" text item">
    <el-table
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      border
      @selection-change="handleSelectionChange">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column
        type= "index"
        label="ID"
        width="50">
      </el-table-column>
      <el-table-column
        prop="knowledgeId"
        label="知识点ID"
        width="200">
      </el-table-column>
      <el-table-column
        prop="knowledgeName"
        label="知识点名称"
        show-overflow-tooltip>
      </el-table-column>
    </el-table>
  </div>
</el-card>
</template>

<script>
export default {
  name: 'TaskAsign',
  data () {
    return {
      tableData: [],
      multipleSelection: [],
      uid: 0
    }
  },
  methods: {
    toggleSelection (rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    handleClick () {
      this.$http.post('/taskmanager/taskAsign.php', [this.multipleSelection, this.uid]).then(res => {
        if (res.data.code === '200') {
          this.$message({
            message: '恭喜你，这是一条成功消息',
            type: 'success'
          })
        }
      })
    }
  },
  mounted () {
    this.$http.get('/taskmanager/tasklist.php').then(res => {
      if (res.data.code === '200') {
        this.tableData = res.data.tableData
      }
    })
  }
}
</script>

<style>

</style>
