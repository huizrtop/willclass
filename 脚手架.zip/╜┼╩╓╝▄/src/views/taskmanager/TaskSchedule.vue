<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>总体任务进度</span>
    </div>
    <div class="text item">
      一共需完成的知识点数：{{count.total}}个，已完成：{{count.deal}}个，未完成：{{count.undeal}}个，有 {{count.dealing}} 个正在处理
      <hr>
    </div>
    <div class="text item">
      <el-row>
        <el-col :span="10">
          <el-radio class = "radio" v-model="selData.status" label="0" border size="small" @change="handleChange">所有任务</el-radio>
          <el-radio class = "radio" v-model="selData.status" label="1" border size="small" @change="handleChange">未处理</el-radio>
          <el-radio class = "radio" v-model="selData.status" label="2" border size="small" @change="handleChange">处理中</el-radio>
          <el-radio class = "radio" v-model="selData.status" label="3" border size="small" @change="handleChange">已完成</el-radio>
        </el-col>
        <el-col :span = "3">
          <span class="seltitle">根据处理人筛选：</span>
        </el-col>
        <el-col :span = "6">
          <el-input size="small" placeholder="请输入处理人" v-model="selData.username" @change="handleChange"></el-input>
        </el-col>
      </el-row>
    </div>
    <div class="text item">
      <el-table :data="tableData" border style="width: 100%; margin-top: 20px">
        <el-table-column prop="username" label="处理人" width="100"></el-table-column>
        <el-table-column prop="knowledgeId" label="知识点ID" width="120"></el-table-column>
        <el-table-column prop="knowledgeName" label="知识点名称" show-overflow-tooltip
          ></el-table-column>
        <el-table-column prop="tcount" label="题目数量" width="80"></el-table-column>
        <el-table-column prop="watchedCount" label="已看题量" width="80"></el-table-column>
        <el-table-column prop="categoryCount" label="抽屉数量" width="80"></el-table-column>
        <el-table-column prop="status" label="当前状态" width="100">
          <template slot-scope="scope">{{ scope.row.status === '1'?'未处理': scope.row.status === '2'?'处理中':'已完成'}}</template>
        </el-table-column>
      </el-table>
    </div>
   </el-card>
</template>

<script>
export default {
  name: 'TaskSchedule',
  data () {
    return {
      count: Object,
      tableData: [ ],
      taskList: [],
      selData: {
        status: '0',
        mark: ''
      }
    }
  },
  mounted () {
    this.$message({ message: '正在加载任务信息，请稍后～', type: 'info' })
    this.$http.get('/taskmanager/taskSchedule.php').then(res => {
      this.taskList = res.data.tableData
      this.tableData = res.data.tableData
      this.count = res.data.count
      this.$message({ message: '任务加载完毕', type: 'success' })
    })
  },
  methods: {
    filter (data) {
      let result = true
      if (parseInt(this.selData.status) !== 0) {
        result = parseInt(this.selData.status) === parseInt(data.status)
      }
      if (result && this.selData.username !== '') {
        let word = '.*' + this.selData.username + '.*'
        let reg = new RegExp(word)
        result = reg.test(data.username)
      }
      return result
    },
    handleChange () {
      this.tableData = this.taskList.filter(data => this.filter(data))
    }
  }
}
</script>

<style>

</style>
