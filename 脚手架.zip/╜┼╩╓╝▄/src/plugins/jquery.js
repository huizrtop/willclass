import jquery from 'jquery'
const jQuery = {}
jQuery.install = (Vue) => {
  Vue.prototype.$ = jquery
}
export default jQuery
