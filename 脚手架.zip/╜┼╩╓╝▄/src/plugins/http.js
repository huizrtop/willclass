import axios from 'axios'
const MyHttpServer = {}
MyHttpServer.install = (Vue) => {
  axios.defaults.baseURL = 'http://172.81.236.47/data/'
  Vue.prototype.$http = axios
}
export default MyHttpServer
