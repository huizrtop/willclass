<?php
  require_once('../../init.php');
 @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误beginentask');
  }
  $sql = "SELECT COUNT(*) FROM english_exercise_reading WHERE task_id = '$input' AND watch = 2";
  $result = mysqli_query($conn,$sql);
  if($result){
    $c = mysqli_fetch_row($result)[0];
  }
  $sql = "UPDATE english_task SET status = 6,countWatched = $c WHERE id = '$input'";
  $result = mysqli_query($conn,$sql);
  if($result){
    echo json_encode(['code'=>200]);
  }
?>