<?php
/**
* 更新题目信息
*/
require_once('../../init.php');
@$input = file_get_contents("php://input");
$input = json_decode($input,true);
$Id = $input[0]['id'];
@$rm = $input[0]['duplicate'];
@$isHot = $input[0]['isHot'];
@$isDrop = $input[0]['isDrop'];
@$mk = $input[0]['marks'];
@$literature = $input[0]['literature'];
@$themeId = $input[0]['themeId'];
@$uname = $input[1];
 
$sql = "UPDATE english_exercise_reading SET watch = 2,uname = '$uname' ";
if($rm !== "" && $rm !== null){
    $sql .= " ,duplicate = $rm ";
}
if($isHot !== "" && $isHot !== null){
  $sql .= " ,isHot = $isHot ";
}
if($isDrop !== "" && $isDrop !== null){
  $sql .= " ,isDrop = $isDrop ";
}
if($literature !== "" && $literature !== null){
    $sql .= " ,literature = '$literature' ";
}
if($themeId !== "" && $themeId !== null){
    $sql .= " ,themeId = '$themeId' ";
}
if($mk !==""&&$mk!==null){
    $sql .= " ,marks = '$mk' ";
}
$sql .= " WHERE id = '$Id'";
$result = mysqli_query($conn, $sql);
if($result){
    echo '{"code":200, "msg":"update succ"}';
}else{
    echo '{"code":500, "msg":"select err"}';
}