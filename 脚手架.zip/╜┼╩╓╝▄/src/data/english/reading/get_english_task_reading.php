<?php
  require_once('../../init.php');
  $tableData = [];
  $sql = "SELECT * FROM english_task WHERE task_type = 2 AND forbid = 1 ORDER BY status DESC";
  $result = mysqli_query($conn,$sql);
  if($result){
    $rows = mysqli_fetch_all($result,MYSQLI_ASSOC);
    foreach($rows as $row){
      $item = [];
      $item['maink'] = $row['mainknowledge'];
      $item['tcount'] = $row['tcount'];
      $item['status'] = $row['status'];
      $item['id'] = $row['id'];
      $task_id = $row['id'];
      $sql = "SELECT COUNT(*) FROM english_exercise_reading WHERE task_id = $task_id AND watch = 2";
      $result = mysqli_query($conn,$sql);
      if($result){
        $item['countWatched'] = mysqli_fetch_row($result)[0];
      }
      $tableData[] = $item;
    }
  }
  echo json_encode($tableData);
?>