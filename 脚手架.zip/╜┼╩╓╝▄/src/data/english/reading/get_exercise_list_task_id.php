<?php
  require_once('../../init.php');
  @$input = file_get_contents("php://input");
  $input = json_decode($input,true);
  $task_id = $input[0];
  $count = $input[1];
  $watched = (int)$input[2];
  $sql = "SELECT * FROM english_exercise_reading WHERE task_id = '$task_id' ";
  $tableData = [];
  if($watched != 0){
    $sql .= " AND watch = $watched ";
  }
  $sql .= " ORDER BY tid DESC,order_m LIMIT 0,$count ";
  $result = mysqli_query($conn,$sql);
  if($result){
    $rows = mysqli_fetch_all($result,MYSQLI_ASSOC);
    $i = 0;
    foreach($rows as $row){
      $i ++;
      $row['index'] = $i;
      $l = (int)$row['literature'];
      $row['lname'] = $l === 1 ? '记叙文' : ($l === 2 ? '议论文' : ($l === 3 ? '说明文' : ($l === 4 ? '夹叙夹议文' : ($l === 5 ? '应用文' : ''))));
      $t = $row['themeId'];
      if($t){
        $tarr = explode("#",$t);
        $tname = [];
        $tfu = [];
        foreach($tarr as $tid){
          $sql = "SELECT themeName,fatherId FROM english_theme WHERE id = $tid ";
          $result = mysqli_query($conn,$sql);
          if($result){
            $rows1 = mysqli_fetch_row($result);
            $tname[] = $rows1[0];
            $tfui = [];
            array_unshift($tfui,$rows1[0]);
            $fid = $rows1[1];
            if($fid !== '100000000000'){
              $sql = "SELECT themeName,fatherId FROM english_theme WHERE id = $fid ";
              $result = mysqli_query($conn,$sql);
              if($result){
                $rows2 = mysqli_fetch_row($result);
                array_unshift($tfui,$rows2[0]);
              }
            }
          }
          $tfu[] = implode("-",$tfui);
        }
        $row['themeName'] = implode("#",$tname);
        $row['lfuname'] = implode("#",$tfu);
      }else{
        $row['themeName'] = '';
        $row['lfuname'] = '';
      }
      $tableData[] = $row;
    }
  }
  echo json_encode($tableData);
  ?>