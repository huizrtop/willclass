<?php
  require_once('../../init.php');
  @$input = file_get_contents("php://input");
  $input = json_decode($input,true);
  $task_id = $input[0];
  $watched = (int)$input[1];
  $sql = "SELECT COUNT(*) FROM english_exercise_reading WHERE task_id = '$task_id' ";
  if($watched != 0){
    $sql .= " AND watch = $watched ";
  }
  $result = mysqli_query($conn,$sql);
  if($result){
    $row = mysqli_fetch_row($result)[0];
    echo $row;
  }
?>