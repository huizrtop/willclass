<?php
/**
* 更新题目信息
*/
require_once('../../init.php');
@$input = file_get_contents("php://input");
$input = json_decode($input,true);
@$rows = $input[0];
@$uname = $input[1];
foreach($rows as $row){
  $Id = $row['id'];
  $rm = $row['duplicate'];
  $isHot = $row['isHot'];
  $isDrop = $row['isDrop'];
  $mk = $row['marks'];
  $literature = $row['literature'];
  $themeId = $row['themeId'];  
  $sql = "UPDATE english_exercise_reading SET watch = 2,uname = '$uname' ";
  if($rm !== "" && $rm !== null){
      $sql .= " ,duplicate = $rm ";
  }
  if($isHot !== "" && $isHot !== null){
    $sql .= " ,isHot = $isHot ";
  }
  if($isDrop !== "" && $isDrop !== null){
    $sql .= " ,isDrop = $isDrop ";
  }
  if($literature !== "" && $literature !== null){
      $sql .= " ,literature = '$literature' ";
  }
  if($themeId !== "" && $themeId !== null){
      $sql .= " ,themeId = '$themeId' ";
  }
  if($mk !==""&&$mk!==null){
      $sql .= " ,marks = '$mk' ";
  }
  $sql .= " WHERE id = '$Id'";
  $result = mysqli_query($conn, $sql);
  if($result){
      echo '{"code":200, "msg":"update succ"}';
  }else{
      echo '{"code":500, "msg":"select err"}';
  }
}