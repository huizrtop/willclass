<?php
  require_once('../init.php');
 @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误beginentask');
  }
  $sql = "SELECT subjectId FROM w_user WHERE uname = '$input'";
  $result = mysqli_query($conn,$sql);
  if($result){
    $row = mysqli_fetch_row($result)[0];
    echo $row;
  }
?>