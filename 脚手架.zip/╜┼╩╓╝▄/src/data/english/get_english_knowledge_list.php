<?php
  require_once('../init.php');
  $data = [];
  $sql = "SELECT id,knowledgeName FROM knowledge WHERE subjectId = 6 AND knowledgeGrade = 1";
  $result = mysqli_query($conn,$sql);
  if($result){
    $kn1 = mysqli_fetch_all($result);
    foreach($kn1 as $kn11){
      $kn1id = $kn11[0];
      $kn1name = $kn11[1];
      $sql = "SELECT id,knowledgeName FROM knowledge WHERE fatherId = $kn1id";
      $result = mysqli_query($conn,$sql);
      if($result){
        $kn2 = mysqli_fetch_all($result);
        if(count($kn2)!=0){
          $child1 = [];
          foreach($kn2 as $kn21){
            $kn2id = $kn21[0];
            $kn2name = $kn21[1];
            $sql = "SELECT id,knowledgeName FROM knowledge WHERE fatherId = $kn2id";
            $result = mysqli_query($conn,$sql);
            if($result){
              $kn3 = mysqli_fetch_all($result);
              if(count($kn3) !=0 ){
                $child2 = [];
                  foreach($kn3 as $kn31){
                  $kn3id = $kn31[0];
                  $kn3name = $kn31[1];
                  $child2[] = ['id'=>$kn3id,'label'=>$kn3name];
                }
                $child1[] = ['id'=>$kn2id,'label'=>$kn2name,'children'=>$child2];
              }else{
                $child1[] = ['id'=>$kn2id,'label'=>$kn2name];
              }
            }
          }
          $data[] = ['id'=>$kn1id,'label'=>$kn1name,'children'=>$child1];
        }else{
          $data[] = ['id'=>$kn1id,'label'=>$kn1name];
        }
      }
    }
    echo json_encode($data);
  }
?>