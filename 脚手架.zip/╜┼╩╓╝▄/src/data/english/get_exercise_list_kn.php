<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  $input = json_decode($input,true);
  $kn = $input[0];
  $count = $input[1];
  $watched = (int)$input[2];
  $type = $input[3];
  $sql = "SELECT id,tid,type,mainknowledge,knowledge,duplicate,dupid,marks,isDemo,watch,newknowledge,newknname,category FROM english_exercise WHERE 1 ";
  if($watched != 0){
    $sql .= " AND watch = $watched ";
  }
  if($type == "主要知识点"){
    $sql .= "  AND mainknowledge = '$kn' ";
  }else{
    $sql .= "  AND knowledge = '$kn' ";
  }
  $result = mysqli_query($conn,$sql);
  if($result){
    $row = mysqli_fetch_all($result,MYSQLI_ASSOC);
    shuffle($row);
    $reg = array_slice($row,0,$count);
    $i = 0;
    $get = [];
    foreach($reg as $item){
      $kidlist = $item['newknowledge'];
      if(strlen($kidlist)>10){
        $kidarr = explode("#",$kidlist);
        $kn = [];
        $knf = [];
        foreach($kidarr as $kid){
          $knfi = [];
          $sql = "SELECT knowledgeName,fatherId FROM knowledge WHERE id = '$kid'";
          $result = mysqli_query($conn,$sql);
          if($result){
            $row1 = mysqli_fetch_row($result);
            $kn[] = $row1[0];
            array_unshift($knfi,$row1[0]);
            $fid = $row1[1];
            if($fid != '100000000000'){
              $sql = "SELECT knowledgeName,fatherId FROM knowledge WHERE id = '$fid'";
              $result = mysqli_query($conn,$sql);
              if($result){
                $row2 = mysqli_fetch_row($result);
                array_unshift($knfi,$row2[0]);
                $fid = $row2[1];
                if($fid != '100000000000'){
                  $sql = "SELECT knowledgeName,fatherId FROM knowledge WHERE id = '$fid'";
                  $result = mysqli_query($conn,$sql);
                  if($result){
                    $row3 = mysqli_fetch_row($result);
                    array_unshift($knfi,$row3[0]);
                  }
                }
              }
            }
          }
          $knf[]=implode("-",$knfi);
        }
        $item['newknname'] = implode("#",$kn);
        $item['newfuname'] = implode("#",$knf);
      }else{
        $item['newknname'] = '';
        $item['newfuname'] = '';
      }
      $item['index'] = $i;
      $i ++;
      $get[] = $item;
    }
    echo json_encode($get);
  }
?>