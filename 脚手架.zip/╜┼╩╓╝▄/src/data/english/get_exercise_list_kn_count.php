<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  $input = json_decode($input,true);
  $kn = $input[0];
  $watched = (int)$input[1];
  $type = $input[2];
  $sql = "SELECT COUNT(*) FROM english_exercise WHERE 1 ";
  if($watched != 0){
    $sql .= " AND watch = $watched ";
  }
  if($type == "主要知识点"){
    $sql .= "  AND mainknowledge = '$kn' ";
  }else{
    $sql .= "  AND knowledge = '$kn' ";
  }
  $result = mysqli_query($conn,$sql);
  if($result){
    $row = mysqli_fetch_row($result)[0];
    echo $row;
  }
?>