<?php
  require_once('../init.php');
  $sql = "SELECT COUNT(*) FROM english_task WHERE status = 2";
  $result = mysqli_query($conn,$sql);
  if($result){
    $row = mysqli_fetch_row($result)[0];
    echo $row;
  }
?>