<?php
  require_once('../init.php');
  $tableData = [];
  $count = [];
  $kn = [];
  $sql = "SELECT * FROM english_task WHERE task_type = 1 ORDER BY status DESC";
  $result = mysqli_query($conn,$sql);
  if($result){
    $tableData = mysqli_fetch_all($result,MYSQLI_ASSOC);
  }
  $sql = "SELECT COUNT(*) FROM english_task  WHERE task_type = 1";
  $result = mysqli_query($conn,$sql);
  if($result){
    $count['total'] = mysqli_fetch_row($result)[0];
  }
  $sql = "SELECT COUNT(*) FROM english_task WHERE status = 1 AND task_type = 1";
  $result = mysqli_query($conn,$sql);
  if($result){
    $count['undeal'] = mysqli_fetch_row($result)[0];
  }
  $sql = "SELECT mainknowledge, COUNT(*) FROM english_task WHERE status = 2 AND task_type = 1";
  $result = mysqli_query($conn,$sql);
  if($result){
    $row = mysqli_fetch_row($result);
    $kn['mainknowledge'] = $row[0];
    $count['dealing'] = $row[1];
    $sql = "SELECT mainknowledge,COUNT(*) FROM english_exercise WHERE mainknowledge = '$row[0]'";
    $result = mysqli_query($conn,$sql);
    if($result){
      $rows = mysqli_fetch_row($result);
      $kn['type'] = '主要知识点';
      $kn['tcount'] = $rows[1];
      $sql = "SELECT mainknowledge,COUNT(*) FROM english_exercise WHERE mainknowledge = '$rows[0]' AND watch = 2";
      $result = mysqli_query($conn,$sql);
      if($result){
        $kn['countWatched'] = mysqli_fetch_row($result)[1];
        $kn['status'] = 2;
    }
    }
  }
  $sql = "SELECT COUNT(*) FROM english_task WHERE status = 3";
  $result = mysqli_query($conn,$sql);
  if($result){
    $count['deal'] = mysqli_fetch_row($result)[0];
  }
  $output = ['tableData'=>$tableData,'count'=>$count,'kn'=>$kn];
  echo json_encode($output);
?>