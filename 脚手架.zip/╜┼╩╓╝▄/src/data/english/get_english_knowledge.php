<?php
 require_once('../init.php');
 @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误getknmap');
  }
 $kntable = [];
 $kn1space = [];
 $kn2space = [];
$sql = "SELECT id,knowledgeName FROM knowledge WHERE knowledgeGrade = 1 AND subjectId = $input";
$result = mysqli_query($conn,$sql);
if($result){
  $kn1 = mysqli_fetch_all($result);
  foreach($kn1 as $kn11){
    $kn1id = $kn11[0];
    $kn1name = $kn11[1];
    $kn21space = 0;
    $sql = "SELECT id,knowledgeName FROM knowledge WHERE fatherId = $kn1id";
    $result = mysqli_query($conn,$sql);
    if($result){
      $kn2 = mysqli_fetch_all($result);
      foreach($kn2 as $kn21){
        $kn2id = $kn21[0];
        $kn2name = $kn21[1];
        $sql = "SELECT id,knowledgeName FROM knowledge WHERE fatherId = $kn2id";
        $result = mysqli_query($conn,$sql);
        if($result){
          $kn3 = mysqli_fetch_all($result);
          if(count($kn3)==0){
            $kn2space[]=1;
            $kn21space += 1;
            $tableitem = ['kn1'=>$kn1name,'kn2'=>$kn2name,'kn3'=>''];
            $kntable[] = $tableitem;
          }else{
            $kn2space[] = count($kn3);
            $kn21space += count($kn3);
            foreach($kn3 as $kn31){
              $tableitem = ['kn1'=>$kn1name,'kn2'=>$kn2name,'kn3'=>$kn31[1]];
              $kntable[] = $tableitem;
            }
          }
        }
      }
    }
    $kn1space[] = $kn21space;
  }
}
$output = ['kntable'=>$kntable,'kn1space'=>$kn1space,'kn2space'=>$kn2space];
echo json_encode($output);
?>