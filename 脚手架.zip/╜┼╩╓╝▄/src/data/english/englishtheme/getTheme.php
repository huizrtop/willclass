<?php
  require_once('../../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    $input = '100000000000';
  }
  $info = [];
  $tableData = [];
  $crumb = [];
  $info['fatherId'] = $input;
  if($input != '100000000000'){
    $sql = "SELECT id,themeName,fatherId FROM english_theme WHERE id = '$input' ";
    $result = mysqli_query($conn,$sql);
    if($result){
      $row = mysqli_fetch_row($result);
      if(count($row)!=0){
        array_unshift($crumb,['id'=>$row[2],'themeName'=>$row[1]]);
        if($row[2] != '100000000000'){
          $sql = "SELECT id,themeName,fatherId FROM english_theme WHERE id = '$row[2]' ";
          $result = mysqli_query($conn,$sql);
          if($result){
            $row = mysqli_fetch_row($result);
            if(count($row)!=0){
              array_unshift($crumb,['id'=>$row[2],'themeName'=>$row[1]]);
            }
          }
        }
      }
    }
  }
  $sql = "SELECT * FROM english_theme WHERE fatherId = '$input'";
  $result = mysqli_query($conn,$sql);
  if($result){
    $rows = mysqli_fetch_all($result,MYSQLI_ASSOC);
    if(count($rows) != 0){
      $info['themeGrade'] = $rows[0]['themeGrade'];
    }else{
      $info['themeGrade'] = 1;
    }
    $info['themeName'] = '';
    $info['status']='1';
    foreach($rows as $row){
      $id = $row['id'];
      $sql = "SELECT COUNT(*) FROM english_theme WHERE fatherId = '$id'";
      $result = mysqli_query($conn,$sql);
      if($result){
        $r = mysqli_fetch_row($result)[0];
        if($r == 0){
          $row['children'] = 0;
        }else{
          $row['children'] = 1;
        }
      }
      $tableData[]=$row;
    }
  }
  $output = ['info'=>$info,'tableData'=>$tableData,'crumb'=>$crumb];
  echo json_encode($output);
?>