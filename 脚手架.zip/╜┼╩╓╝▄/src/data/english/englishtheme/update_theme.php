<?php
  require_once('../../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误addtheme');
  }
  $form = json_decode($input,true);
  $id = $form['id'];
  $themeName = $form['themeName'];
  $status = $form['status'];
  $sql = "UPDATE english_theme SET themeName = '$themeName',status = '$status' WHERE id = '$id'";
  $result = mysqli_query($conn,$sql);
  if($result){
    echo json_encode(['code'=>200]);
  }
  ?>