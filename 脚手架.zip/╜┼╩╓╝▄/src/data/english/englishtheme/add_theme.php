<?php
  require_once('../../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误addtheme');
  }
  $input = json_decode($input,true);
  $form = $input[0];
  $type = (int)$input[1];
  $fatherId = $form['fatherId'];
  $themeName = $form['themeName'];
  $status = $form['status'];
  $themeGrade = (int)$form['themeGrade'];
  if($type == 2){
    $themeGrade += 1;
  }
  $sql = "SELECT COUNT(*) FROM english_theme WHERE fatherId = '$fatherId'";
  $result = mysqli_query($conn,$sql);
  if($result){
    $c = (int)mysqli_fetch_row($result)[0];
    $sql = "SELECT searchIndex FROM english_theme WHERE id = '$fatherId'";
    $result = mysqli_query($conn,$sql);
    if($result){
      $findex = mysqli_fetch_row($result)[0];
      $index = (int)substr($findex,0,2*$themeGrade+1);
      $index = $index + $c + 1;
      for($i = 2*$themeGrade+1;$i<18;$i++){
        $index .= '0';
      }
    }
    $sql = "INSERT INTO english_theme(id,themeName,fatherId,status,searchIndex,themeGrade) VALUES(NULL,'$themeName','$fatherId','$status','$index',$themeGrade)";
    $result = mysqli_query($conn,$sql);
    if($result){
      echo json_encode(['code'=>200]);
    }
  }
  ?>