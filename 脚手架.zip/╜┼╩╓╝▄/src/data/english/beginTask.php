<?php
  require_once('../init.php');
 @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误beginentask');
  }
  $sql = "UPDATE english_task SET status = 2 WHERE mainknowledge = '$input'";
  $result = mysqli_query($conn,$sql);
?>