<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误exmap');
  }
  $sql = "SELECT mainknowledge,COUNT(*) FROM english_exercise WHERE type = '$input' GROUP BY mainknowledge";
  $result = mysqli_query($conn,$sql);
  $tableData = [];
  if($result){
    $rows = mysqli_fetch_all($result);
    $id = 0;
    foreach($rows as $row){
      $id ++;
      $sql = "SELECT COUNT(*) FROM english_exercise WHERE type = '$input' AND mainknowledge = '$row[0]' AND watch = 2";
      $result = mysqli_query($conn,$sql);
      if($result){
        $countWatched = mysqli_fetch_row($result)[0];
      }
      $item = ['id'=>$id,'type'=>'主要知识点','kn'=>$row[0],'count'=>$row[1],'countWatched'=>$countWatched];
      $child = [];
      $mainkn = $row[0];
      $sql = "SELECT knowledge,COUNT(*) FROM english_exercise WHERE type = '$input' AND mainknowledge = '$mainkn' GROUP BY knowledge";
      $result = mysqli_query($conn,$sql);
      if($result){
        $rowss = mysqli_fetch_all($result);
        foreach($rowss as $rowsss){
          $id ++;
          $child[] = ['id'=>$id,'type'=>'知识点','kn'=>$rowsss[0],'count'=>$rowsss[1]];
        }
      }
      $item['children'] = $child;
      $tableData[] = $item;
    }
    echo json_encode($tableData);
  }
?>