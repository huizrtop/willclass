<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  $kidlist = $input;
  if(strlen($kidlist)>10){
    $kidarr = explode("#",$kidlist);
    $knf = [];
    foreach($kidarr as $kid){
      $knfi = [];
      $sql = "SELECT knowledgeName,fatherId FROM knowledge WHERE id = '$kid'";
      $result = mysqli_query($conn,$sql);
      if($result){
        $row1 = mysqli_fetch_row($result);
        array_unshift($knfi,$row1[0]);
        $fid = $row1[1];
        if($fid != '100000000000'){
          $sql = "SELECT knowledgeName,fatherId FROM knowledge WHERE id = '$fid'";
          $result = mysqli_query($conn,$sql);
          if($result){
            $row2 = mysqli_fetch_row($result);
            array_unshift($knfi,$row2[0]);
            $fid = $row2[1];
            if($fid != '100000000000'){
              $sql = "SELECT knowledgeName,fatherId FROM knowledge WHERE id = '$fid'";
              $result = mysqli_query($conn,$sql);
              if($result){
                $row3 = mysqli_fetch_row($result);
                array_unshift($knfi,$row3[0]);
              }
            }
          }
        }
      }
      $knf[]=implode("-",$knfi);
    }
    $newfuname = implode("#",$knf);
  }else{
    $newfuname = '';
  }
  echo json_encode($newfuname);
?>