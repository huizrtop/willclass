<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误regist');
  }
  $output = [];
  $count = [];
  $kinfo = [];
  $sql = "SELECT id,realname FROM w_user  WHERE uname = '$input'";
  $result = mysqli_query($conn,$sql);
  if($result){
    $row = mysqli_fetch_assoc($result);
    $userId = $row['id'];
    $realname = $row['realname'];
    $sql = "SELECT COUNT(*) FROM taskmanage WHERE userId = '$userId'";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['total'] = mysqli_fetch_row($result)[0];
    }
    $sql = "SELECT COUNT(*) FROM taskmanage WHERE userId = '$userId' AND status != 3";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['undeal'] = mysqli_fetch_row($result)[0];
    }
    $sql = "SELECT COUNT(*) FROM taskmanage WHERE userId = '$userId' AND status = 3";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['deal'] = mysqli_fetch_row($result)[0];
    }
    $sql = "SELECT knowledgeId FROM taskmanage WHERE userId = '$userId' AND status = 2";
    $result = mysqli_query($conn,$sql);
    if($result){
      $kid = mysqli_fetch_row($result)[0];
      $sql = "SELECT ct FROM k_count WHERE kid = '$kid'";
      $result = mysqli_query($conn,$sql);
      if($result){
        $ct = mysqli_fetch_row($result)[0];
        $kinfo['ct'] = (int)$ct;
      }
      $sql = "SELECT COUNT(*) FROM exercise WHERE knowledge_33 = '$kid' AND watched = 2";
      $result = mysqli_query($conn,$sql);
      if($result){
        $kinfo['watched'] = (int)mysqli_fetch_row($result)[0];
      }
      $kinfo['watch'] = $kinfo['ct'] - $kinfo['watched'];
      $kinfo['kid'] = $kid;
      $kidarr = explode("#",$kid);
      $kn = [];
      foreach($kidarr as $id){
        $sql = "SELECT knowledgeName FROM knowledge WHERE id = '$id'";
        $result = mysqli_query($conn,$sql);
        if($result){
          $kn[] = mysqli_fetch_row($result)[0];
        }
      }
      $kinfo['kn'] = implode("#",$kn);
    }
    $output = [count=>$count,kinfo=>$kinfo];
    echo json_encode($output);
  }
?>