<?php
  require_once('../init.php');
  $tableData = [];
  $count = [];
  $output = [];
  $sql = "SELECT knowledgeId,userId,categoryCount,status FROM taskmanage WHERE userId IS NOT NULL ORDER BY status DESC";
  $result = mysqli_query($conn,$sql);
    if($result){
      $rows = mysqli_fetch_all($result,MYSQLI_ASSOC);
      foreach($rows as $row){
        $uid = $row['userId'];
        $sql = "SELECT realname FROM w_user WHERE  id = '$uid'";
        $result = mysqli_query($conn,$sql);
        if($result){
          $row['username'] = mysqli_fetch_row($result)[0];
        }
        $kid = $row['knowledgeId'];
        $sql = "SELECT ct FROM k_count WHERE kid = '$kid'";
        $result = mysqli_query($conn,$sql);
        if($result){
          $row['tcount'] = mysqli_fetch_row($result)[0];
        }
        $sql = "SELECT COUNT(*) FROM exercise WHERE knowledge_33 = '$kid' AND watched = 2";
        $result = mysqli_query($conn,$sql);
        if($result){
          $row['watchedCount'] = mysqli_fetch_row($result)[0];
        }
        $kidArr = explode("#",$kid);
        $kn = [];
        foreach($kidArr as $id){
          $sql = "SELECT knowledgeName FROM knowledge WHERE id = '$id'";
          $result = mysqli_query($conn,$sql);
          if($result){
            $kn[] = mysqli_fetch_row($result)[0];
          }
        }
        $row["knowledgeName"] = implode("#",$kn);
        $tableData[] = $row;
      }
    }
    $sql = "SELECT COUNT(*) FROM taskmanage ";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['total'] = mysqli_fetch_row($result)[0];
    }
    $sql = "SELECT COUNT(*) FROM taskmanage WHERE status = 1";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['undeal'] = mysqli_fetch_row($result)[0];
    }
    $sql = "SELECT COUNT(*) FROM taskmanage WHERE status = 2";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['dealing'] = mysqli_fetch_row($result)[0];
    }
    $sql = "SELECT COUNT(*) FROM taskmanage WHERE status = 3";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['deal'] = mysqli_fetch_row($result)[0];
    }
    $output = ['count'=>$count,'tableData'=>$tableData];
    echo json_encode($output);
?>