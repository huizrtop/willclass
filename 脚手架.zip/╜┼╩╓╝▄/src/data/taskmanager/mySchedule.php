<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误regist');
  }
  $output = [];
  $count = [];
  $tableData = [];
  $sql = "SELECT id,realname FROM w_user  WHERE uname = '$input'";
  $result = mysqli_query($conn,$sql);
  if($result){
    $row = mysqli_fetch_assoc($result);
    $userId = $row['id'];
    $realname = $row['realname'];
    $sql = "SELECT knowledgeId,categoryCount,status FROM taskmanage WHERE userId = '$userId' ORDER BY status DESC";
    $result = mysqli_query($conn,$sql);
    if($result){
      $rows = mysqli_fetch_all($result,MYSQLI_ASSOC);
      foreach($rows as $row){
        $row['username'] = $realname;
        $kid = $row['knowledgeId'];
        $sql = "SELECT ct FROM k_count WHERE kid = '$kid'";
        $result = mysqli_query($conn,$sql);
        if($result){
          $row['tcount'] = mysqli_fetch_row($result)[0];
        }
        $kidArr = explode("#",$kid);
        $kn = [];
        foreach($kidArr as $id){
          $sql = "SELECT knowledgeName FROM knowledge WHERE id = '$id'";
          $result = mysqli_query($conn,$sql);
          if($result){
            $kn[] = mysqli_fetch_row($result)[0];
          }
        }
        $row["knowledgeName"] = implode("#",$kn);
        $tableData[] = $row;
      }
    }
    $sql = "SELECT COUNT(*) FROM taskmanage WHERE userId = '$userId'";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['total'] = mysqli_fetch_row($result)[0];
    }
    $sql = "SELECT COUNT(*) FROM taskmanage WHERE userId = '$userId' AND status = 1";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['undeal'] = mysqli_fetch_row($result)[0];
    }
    $sql = "SELECT COUNT(*) FROM taskmanage WHERE userId = '$userId' AND status = 2";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['dealing'] = mysqli_fetch_row($result)[0];
    }
    $sql = "SELECT COUNT(*) FROM taskmanage WHERE userId = '$userId' AND status = 3";
    $result = mysqli_query($conn,$sql);
    if($result){
      $count['deal'] = mysqli_fetch_row($result)[0];
    }
    $output = [count=>$count,tableData=>$tableData];
    echo json_encode($output);
  }
?>