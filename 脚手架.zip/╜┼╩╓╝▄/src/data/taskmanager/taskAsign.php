<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误regist');
  }
  $inputdata = json_decode($input,true);
  $data = $inputdata[0];
  $userId = $inputdata[1];
  foreach($data as $item){
    $knowledgeId = $item['knowledgeId'];
    $sql = "UPDATE taskmanage SET userId = '$userId' WHERE knowledgeId = '$knowledgeId'";
    $result = mysqli_query($conn,$sql);
    if($result){
      echo json_encode(['code'=> "200",'msg'=>"update succ"]);
    }else{
      echo '{code:"500",msg:"update err"}';
    }
  }
?>