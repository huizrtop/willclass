<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误regist');
  }
  $data = json_decode($input);
  $categoryCount = $data[0];
  $kid = $data[1];
  $sql = "SELECT COUNT(*) FROM exercise WHERE knowledge_33 = '$kid' AND watched = 2";
  $result = mysqli_query($conn,$sql);
  if($result){
    $watchedCount = mysqli_fetch_row($result)[0];
  }
  $sql = "UPDATE taskmanage SET status = 3,categoryCount = $categoryCount,watchedCount = $watchedCount WHERE knowledgeId = '$kid'";
  $result = mysqli_query($conn,$sql);
  if($result){
    echo json_encode([code=>'200',msg=>'update succ']);
  }
?>