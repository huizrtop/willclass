<?php
  require_once('../init.php');
  $sql = "SELECT knowledgeId from taskmanage WHERE status = '1'";
  $result = mysqli_query($conn,$sql);
  $tableData = [];
  if($result){
    $rows = mysqli_fetch_all($result);
    foreach($rows as $data){
      $tableItem = [];
      $tableItem['knowledgeId'] = $data[0];
      $idL = explode("#",$data[0]);
      $knL = [];
      foreach($idL as $id){
        $sql = "SELECT knowledgeName FROM knowledge WHERE id = '$id'";
        $result = mysqli_query($conn,$sql);
        if($result){
          $kn = mysqli_fetch_row($result)[0];
          $knL[] = $kn;
        }else{
          echo '{code:500,msg:"sel err1"}';
        }
      }
      $knll = implode("#",$knL);
      $tableItem['knowledgeName'] = $knll;
      $tableData[] = $tableItem;
    }
    $output = [
      'code'=>'200',
      'tableData'=>$tableData
    ];
    echo json_encode($output);
  }else{
    echo '{code:500,msg:"sel err1"}';
  }
?>