<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误regist');
  }
  $sql = "UPDATE taskmanage SET status = 2 WHERE knowledgeId = '$input'";
  $result = mysqli_query($conn,$sql);
  if($result){
    echo json_encode([code=>'200',msg=>'update succ']);
  }
?>