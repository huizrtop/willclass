<?php
/*获取知识点组合及其题量*/
require_once('./../init.php');
@$input = file_get_contents("php://input");
$idlist = json_decode($input,true);
$outlist = [];
foreach($idlist as $item){
  $kid = $item['kid'];
  $kidarr = explode("#",$kid);
  $idname = [];
  foreach($kidarr as $id){
    $sql = "SELECT knowledgeName FROM knowledge WHERE id = '$id'";
    $result = mysqli_query($conn,$sql);
    if($result){
      $name = mysqli_fetch_row($result)[0];
    }
    $idname[] = $name.$id;
  }
  $outlist[] = ["id"=>$item['id'],"idname"=>$idname,'ct'=>$item['ct']];
}
echo json_encode($outlist);
?>