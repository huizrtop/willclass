<?php
  require_once('../init.php');
  @$input = file_get_contents("php://input");
  if($input === '' || $input === null){
    die('参数错误clearStorage');
  }
  $sql = "UPDATE exercise_log SET status = 2 WHERE uname = '$input' AND status = 1";
  $result = mysqli_query($conn,$sql);
  if($result){
    echo json_encode([code=>'200',msg=>'update succ']);
  }
?>