<?php
/**
* 获取题目列表
*/
require_once('./../init.php');
@$input = file_get_contents("php://input");
$id = json_decode($input,true);
$Id = $id[0];
$watched = (int)$id[2];
$output = array();
$total = 0;
$y = 0;
$j = 0;
$g = 0;
$sql = "SELECT COUNT(*) AS total FROM exercise WHERE knowledge_3 = '$Id' ";
if($watched === 1 || $watched === 2){
    $sql .= " AND watched = $watched ";
}
//echo $sql;
$result = mysqli_query($conn, $sql);
if($result){
    $total = mysqli_fetch_row($result)[0];
}else{
    echo '{"code":500, "msg":"select err"}';
}
$sql = "SELECT quality,COUNT(*) AS c FROM exercise WHERE knowledge_3 = '$Id' ";
if($watched === 1 || $watched === 2){
    $sql .= " AND watched = $watched ";
}
$sql .= " GROUP BY quality ";
//echo $sql;
$result = mysqli_query($conn, $sql);
if($result){
    $list = mysqli_fetch_all($result, MYSQLI_ASSOC);
    foreach($list as $l){
        if($l["quality"]=="一般"){
            $y = $l["c"];
        }elseif($l["quality"]=="较高"){
            $j = $l["c"];
        }else{
            $g = $l["c"];
        }
    }
}else{
    echo '{"code":500, "msg":"select err"}';
}
 
@$c = (int)$id[1];
$yl = [];
$jl = [];
$gl = [];
$sql = "SELECT id,tid,watched,quality,type,(SELECT knowledgeName FROM knowledge WHERE id = '$Id') AS knowledgeName,remark,unusual,marks,isDemo,categoryId FROM exercise WHERE knowledge_3 = '$Id' ";
if($watched === 1 || $watched === 2){
    $sql .= " AND watched = $watched ";
}
$sql .= " ORDER BY priority DESC ";
//echo $sql;
$result = mysqli_query($conn, $sql);
if($result){
    $list = mysqli_fetch_all($result, MYSQLI_ASSOC);
    foreach($list as $l){
        if($l["quality"]=="一般"){
            $yl[] = $l;
        }elseif($l["quality"]=="较高"){
            $jl[] = $l;
        }else{
            $gl[] = $l;
        }
    }
}else{
    echo '{"code":500, "msg":"select err"}';
}
shuffle($yl);
shuffle($jl);
shuffle($gl);
$gc = count($gl);
$jc = count($jl);
$yc = count($yl);
if($c < $total){
    $gc1 = $c * 0.34;
    $jc1 = $c * 0.34;
    $yc1 = $c - $gc1 - $jc1;
    if($gc < $gc1){
        $c -= $gc;
        $jc1 = $c * 0.5;
        $yc1 = $c - $jc1;
        if($jc > $jc1){
            $jc = $jc1;
        }
        $yc = $c - $jc;
    }else{
        $gc = $gc1;
        if($jc > $jc1){
            $jc = $jc1;
        }
        $yc = $c - $jc;
    }
}
$reg = array_slice($gl,0,$gc);
$rej = array_slice($jl,0,$jc);
$rey = array_slice($yl,0,$yc);
$res = array_merge($reg,$rej,$rey);
echo json_encode($res);