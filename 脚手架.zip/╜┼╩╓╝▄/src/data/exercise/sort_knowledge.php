<?php
require_once('./../init.php');
$start = $_REQUEST['start'];
$count = 0;
$sql = "SELECT id,knowledge_3 FROM exercise LIMIT $start,2000";
$result = mysqli_query($conn,$sql);
if($result){
  $rows = mysqli_fetch_all($result,MYSQLI_ASSOC);
  foreach($rows as $item){
    $id = $item['id'];
    $karray = explode("#",$item['knowledge_3']);
    sort($karray);
    $knowledge_33 = implode("#",$karray);
    $sql = "UPDATE exercise SET knowledge_33 = '$knowledge_33' WHERE id = $id";
    mysqli_query($conn,$sql);
    $count++;
  }
  echo $start."完成".$count;
}

?>