<?php
/**
* 更新题目信息
*/
require_once('./../init.php');
@$input = file_get_contents("php://input");
$input = json_decode($input,true);
@$rows = $input[0];
@$uname = $input[1];
foreach($rows as $row){
  $Id = $row['id'];
  $tid = $row['tid'];
  $rm = $row['remark'];
  $un = $row['unusual'];
  $isD = $row['isDemo'];
  $mk = $row['marks'];
  $type = $row['type'];
  
  $sql = "UPDATE exercise SET watched = 2,uname = '$uname' ";
  if($rm !== "" && $rm !== null){
      $sql .= " ,remark = $rm ";
  }
  if($un !== "" && $un !== null){
      $sql .= " ,unusual = $un ";
  }
  if($isD !== "" && $isD !== null){
      $sql .= " ,isDemo = $isD ";
  }
  if($type !== "" && $type !== null){
      $sql .= " ,type = $type ";
  }
  if($mk !==""&&$mk!==null){
      $sql .= " ,marks = '$mk' ";
  }
  $sql .= " WHERE id = '$Id'";
  $result = mysqli_query($conn, $sql);
  if($result){
      $sql = "UPDATE exercise_log SET status=2 WHERE tid = $tid";
      mysqli_query($conn,$sql);
      echo '{"code":200, "msg":"update succ"}';
  }else{
      echo '{"code":500, "msg":"select err"}';
  }
}