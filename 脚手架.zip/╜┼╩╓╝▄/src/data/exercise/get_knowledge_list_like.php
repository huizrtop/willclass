<?php
/**
* 获取知识点列表
*/
require_once('../init.php');
@$kn = $_REQUEST['kn'];
 if($kn === '' || $kn === null){
  $sql = "SELECT id,knowledgeName FROM knowledge WHERE knowledgeGrade = 3";
 }else{
  $sql = "SELECT id,knowledgeName FROM knowledge WHERE knowledgeName LIKE '%$kn%' AND knowledgeGrade = 3";
}
// echo $sql;
$result = mysqli_query($conn, $sql);
if($result){
    $list = mysqli_fetch_all($result, MYSQLI_ASSOC);
    $output = [
        'code'=>200,
        'data'=>$list
    ];
    echo json_encode($output);
}else{
    echo '{"code":500, "msg":"select err"}';
}