<?php
/**
* 获取题目数量
*/
require_once('./../init.php');
@$input = file_get_contents("php://input");
$id = json_decode($input,true);
$Id = $id[0];
$watched = (int)$id[1];
$output = array();
$total = 0;
$y = 0;
$j = 0;
$g = 0;
$sql = " SELECT COUNT(*) AS total FROM exercise WHERE knowledge_3 = '$Id' ";
if($watched === 1 || $watched === 2){
    $sql .= " AND watched = $watched ";
}
//echo $sql;
$result = mysqli_query($conn, $sql);
if($result){
    $total = mysqli_fetch_row($result)[0];
}else{
    echo '{"code":500, "msg":"select err"}';
}
$sql = "SELECT quality,COUNT(*) AS c FROM exercise WHERE knowledge_3 = '$Id' ";
if($watched === 1 || $watched === 2){
    $sql .= " AND watched = $watched ";
}
$sql .= " GROUP BY quality ";
//echo $sql;
$result = mysqli_query($conn, $sql);
if($result){
    $list = mysqli_fetch_all($result, MYSQLI_ASSOC);
    foreach($list as $l){
        if($l["quality"]=="一般"){
            $y = $l["c"];
        }elseif($l["quality"]=="较高"){
            $j = $l["c"];
        }else{
            $g = $l["c"];
        }
    }
    $output=["id"=>$Id,"total"=>$total,"y"=>$y,"j"=>$j,"g"=>$g];
    echo json_encode($output);
}else{
    echo '{"code":500, "msg":"select err"}';
}