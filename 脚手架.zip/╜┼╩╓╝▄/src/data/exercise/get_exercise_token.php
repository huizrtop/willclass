<?php
/**
* 获取题目列表
*/
require_once('./../init.php');
@$uname = file_get_contents("php://input");
$list = [];
$sql = "SELECT tid FROM exercise_log WHERE uname = '$uname' AND status = 1";
$result = mysqli_query($conn, $sql);
if($result){
  $tidlist = mysqli_fetch_all($result,MYSQLI_ASSOC);
  foreach($tidlist as $tid){
    $tid = $tid['tid'];
    $sql = "SELECT id,tid,watched,quality,type,knowledge_3,(SELECT knowledgeName FROM knowledge WHERE id = knowledge_3) AS knowledgeName,remark,unusual,marks,isDemo,categoryId FROM exercise WHERE tid = '$tid'";
    $result = mysqli_query($conn,$sql);
    if($result){
      $row = mysqli_fetch_assoc($result);
      $list[] = $row;
    }
  }
  echo json_encode($list);
}

?>