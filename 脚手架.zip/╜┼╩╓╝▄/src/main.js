import Vue from 'vue'
import App from './App.vue'
import router from './router'
import MyHttpServer from '@/plugins/http.js'
import '@/assets/css/base.css'
import jQuery from '@/plugins/jquery.js'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

Vue.use(MyHttpServer)
Vue.use(jQuery)
Vue.use(ElementUI)
Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
