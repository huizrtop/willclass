<template>
  <div class="listbox">
    <list-item v-for="(item, index) in resdata" :key ='index'  @handleClick="handleClick">{{item.knowledgeName+item.id}}</list-item>
  </div>
</template>

<script>
import ListItem from './ListItem.vue'
export default {
  name: 'ListBox',
  props: {
    resdata: Array
  },
  components: {
    ListItem
  },
  methods: {
    handleClick (val) {
      this.$emit('addKn', val)
    }
  }
}
</script>

<style>
  .listbox{
    width: 100%;
    border: 1px solid #dddddd;
    border-bottom-right-radius: 5px;
    border-bottom-left-radius: 5px;
    background: rgb(219, 24, 24);
    position: relative;
  }
</style>
