<template>
  <div class="autocomplete">
    <input-box @inptchange="handlechange"  @handleKey = 'handleKeyDown'></input-box>
    <list-box :resdata = 'resdata' @addKn="addKn" v-if="resdata.length !== 0"></list-box>
  </div>
</template>

<script>
import InputBox from './InputBox.vue'
import ListBox from './ListBox'
export default {
  name: 'AutoComplete',
  components: {
    InputBox,
    ListBox
  },
  data () {
    return {
      alldata: [],
      resdata: []
    }
  },
  methods: {
    handlechange (val) {
      if (val !== '') {
        let word = '.*' + val + '.*'
        let reg = new RegExp(word)
        this.resdata = this.alldata.filter(data => reg.test(data.knowledgeName))
      } else {
        this.resdata = []
      }
    },
    handleKeyDown (val) {
      if (val === 13) {
        if (this.$('.listitem.selected').length !== 0) {
          this.addKn(this.$('.listitem.selected').html())
        }
      } else if (val === 40 && this.resdata.length !== 0) {
        if (this.$('.listitem.selected').length === 0) {
          this.$('.autocomplete .listitem:first-child').addClass('selected')
        } else {
          if (this.$('.listitem.selected').index() + 1 === this.resdata.length) {
            this.$('.autocomplete .listitem:first-child').addClass('selected')
            this.$('.listitem.selected').removeClass('selected')
          } else {
            this.$('.listitem.selected').removeClass('selected').next().addClass('selected')
          }
        }
      } else if (val === 38 && this.resdata.length !== 0) {
        if (this.$('.listitem.selected').length === 0) {
          this.$('.autocomplete .listitem:last-child').addClass('selected')
        } else {
          if (this.$('.listitem.selected').index() === 0) {
            this.$('.listitem.selected').removeClass('selected')
            this.$('.autocomplete .listitem:last-child').addClass('selected')
          } else {
            this.$('.listitem.selected').removeClass('selected').prev().addClass('selected')
          }
        }
      }
    },
    addKn (val) {
      this.$emit('addKn', val)
      this.resdata = []
      this.$('.inputbox input').val('')
    }
  },
  mounted () {
    this.$http.get('exercise/get_knowledge_list_like.php').then(res => {
      this.alldata = res.data.data
    })
  }
}
</script>

<style>
  .autocomplete{
    width: 400px;
    height: 40px;
    margin-bottom: 15px;
    z-index: 8;
  }
</style>
