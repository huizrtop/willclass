<template>
  <div class="listitem" @click="handleClick($event)">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'ListItem',
  methods: {
    handleClick (event) {
      this.$emit('handleClick', this.$(event.target).html())
    }
  }
}
</script>

<style>
  .listitem{
    padding-left: 10px;
    border-bottom: 1px dashed #EEE;
    height: 35px;
    line-height: 35px;
    background: #ffffff;
  }
  .listitem:hover, .listitem.selected{
    background: #D3816A;
  }
</style>
