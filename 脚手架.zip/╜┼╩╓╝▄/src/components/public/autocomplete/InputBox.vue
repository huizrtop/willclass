<template>
  <div class="inputbox">
    <input type="text" v-model="inptval" placeholder="请输入你要搜索的知识点" @keydown="handlekeydown($event)">
    <span>Search</span>
  </div>
</template>

<script>
export default {
  name: 'InputBox',
  data () {
    return {
      inptval: ''
    }
  },
  watch: {
    inptval () {
      this.$emit('inptchange', this.inptval)
    }
  },
  methods: {
    handlekeydown (event) {
      this.$emit('handleKey', event.keyCode)
    }
  }
}
</script>

<style>
  .inputbox{
    width: 100%;
    height: 100%;
    border: 2px solid #808080;
    border-right-color: #637EFF;
    box-sizing: border-box;
    border-radius: 5px;
  }
  .inputbox input{
    display: inline-block;
    width: 80%;
    height: 100%;
    box-sizing: border-box;
    padding-left: 10px;
    font-size: 16px;
  }
  .inputbox span{
    display: inline-block;
    width: 20%;
    height: 100%;
    text-align: center;
    line-height: 36px;
    background: #637EFF;
    cursor: pointer;
  }
</style>
