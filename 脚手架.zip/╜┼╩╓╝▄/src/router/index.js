import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/login/Login.vue'
import Regist from '../views/regist/Regist.vue'
import Exercise from '../views/exercise1/Exercise.vue'
import EnglishExercise from '../views/englishexercise/EnglishExercise.vue'
import EnglishReading from '../views/englishreading/EnglishReading.vue'
import Home from '../views/Home.vue'
import MyTask from '../views/taskcenter/MyTask.vue'
import MySchedule from '../views/taskcenter/MySchedule.vue'
import FinishRegist from '../views/taskcenter/FinishRegist.vue'
import TaskAsign from '../views/taskmanager/TaskAsign.vue'
import TaskSchedule from '../views/taskmanager/TaskSchedule.vue'
import EnglishKnowledge from '../views/englishsubject/EnglishKnowledge.vue'
import EnglishExerciseMap from '../views/englishsubject/EnglishExerciseMap.vue'
import EnglishTaskSchedule from '../views/englishsubject/EnglishTaskSchedule.vue'
import EnglishTheme from '../views/englishsubject/EnglishTheme.vue'
import MathKnowledge from '../views/mathsubject/MathKnowledge.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/regist',
    name: 'regist',
    component: Regist
  },
  {
    path: '/home',
    component: Home,
    children: [
      {
        path: '/',
        name: 'mytask',
        component: MyTask
      },
      {
        path: 'myschedule',
        name: 'myschedule',
        component: MySchedule
      },
      {
        path: 'taskasign',
        name: 'taskasign',
        component: TaskAsign
      },
      {
        path: 'taskschedule',
        name: 'taskschedule',
        component: TaskSchedule
      },
      {
        path: 'finishregist',
        name: 'finishregist',
        component: FinishRegist
      },
      {
        path: 'englishknowledge',
        name: 'englishknowledge',
        component: EnglishKnowledge
      },
      {
        path: 'englishexercisemap',
        name: 'englishexercisemap',
        component: EnglishExerciseMap
      },
      {
        path: 'englishtaskschedule',
        name: 'englishtaskschedule',
        component: EnglishTaskSchedule
      },
      {
        path: 'englishtheme',
        name: 'englishtheme',
        component: EnglishTheme
      },
      {
        path: 'mathknowledge',
        name: 'mathknowledge',
        component: MathKnowledge
      }
    ]
  },
  {
    path: '/exercise',
    name: 'exercise',
    component: Exercise
  },
  {
    path: '/en_exercise',
    name: 'en_exercise',
    component: EnglishExercise
  },
  {
    path: '/en_reading',
    name: 'en_reading',
    component: EnglishReading
  },
  {
    path: '/knowledge',
    name: 'knowledge',
    component: () => import('../views/knowledge/Knowledge.vue')
  }
]

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes
})

export default router
